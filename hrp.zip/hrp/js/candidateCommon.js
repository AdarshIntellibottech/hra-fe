
function checkSession() {
    $.ajax({
        type: "POST",
        url: baseUrl + "api/User/IsTokenValid",
        dataType: "json",
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({
            UserName: $("#loginDetails").text(),
            Roles: "Candidate"
        }),
        success: function (response) {
            var res = JSON.parse(response);
            if (res == false) {
                $.alert({
                    icon: "fas fa-exclamation-circle fa-5x",
                    title: "",
                    theme: "my-theme",
                    content: "Session Timed Out",
                    buttons: {
                        ok: function () {

                            window.location.assign(accessUrl + "/CandidateLogin.html");
                        }
                    }
                });
            } else {
                return;
            }
        },
        error: function (jqXHR, error, errorThrown) {
            if (jqXHR.status && jqXHR.status == 400) {
                window.location.assign(accessUrl + "/502.html");
            } else {
                window.location.assign(accessUrl + "/502.html");
            }
        }
    });
}
$(document).ready(function () {
    //check token validity

    setInterval(checkSession, 1200000);

    //clear value of privacy and logout
    $("#logOut").on("click", function () {
        window.location.href = accessUrl + "/CandidateLogout.html";

    });
});