
$(document).ready(function () {
  // Get user info
  $.ajax({
    type: "GET",
    url: baseUrl + "api/User/LoggedUserDetails",
    dataType: "json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    success: function (response) {
      var res = JSON.parse(response);
      if (res.output_data.length == 0) {
        window.location.assign(accessUrl + "/502.html");
      }
      var userName = res.output_data[0]['UserID'];
      var roleType = res.output_data[0]['Role'];
      var loginDetails = res.output_data[0]['UserID'];
      $("#loginDetails").text(userName);

      // check if username exists
      if (loginDetails == "" || loginDetails == null) {
        window.location.href = accessUrl + "/Login.html";
      }
      // check if username exists

      let additionalInfoUrl = baseUrl + "api/CommonDDL/GetCommonDDL";

      $("#roleType").val(roleType);

      // if HROPS login --> hide action dropdown
      if (roleType == "HROps") {
        $("#action")
          .parent()
          .hide();
      }
      // if HROPS login --> hide action dropdown

      //drawing candidate table using dataTable
      var subDataUrl = baseUrl + "api/Candidate/GetCandidateList";
      var oTable = $("#candidateTable").DataTable({
        columnDefs: [
          {
            orderable: false,
            className: "select-checkbox",
            targets: 0
          }
        ],
        select: {
          style: "single"
        },
        info: false,
        order: [[8, "desc"]],
        scrollX: true,
        searching: true,
        search: {
          regex: true
        },
        processing: true,
        serverSide: true,
        paging: true,
        ajax: {
          url: subDataUrl,
          type: 'POST',
          crossDomain: true,
          xhrFields: { withCredentials: true },
          "data": function (d) {
            d.userid = loginDetails;
            d.role = roleType;

          }
        },

        columns: [
          { data: null, defaultContent: "" },
          {
            data: "StaffID",
            render: function (data, type, row, meta) {
              if (row.StaffID == 0) {
                return null;
              } else return row.StaffID;
            }
          },
          {
            data: "CandidateID",

            render: function (data, type, row, meta) {
              return (
                '<a style="color:#3032c1;cursor:pointer" onclick="getDetails(this)">' +
                data +
                "</a>"
              );
            }
          },
          {
            data: "CandidateFirstName",
            render: function (data, type, row, meta) {
              return row.CandidateFirstName + " " + row.CandidateLastName;
            }
          },
          { data: "CandidatePreferredName" },
          { data: "CandidateEmailID" },
          { data: "CandidateMobileNo" },
          { data: "CountryOfResidence" },
          // { data: "StartDate" },
          {
            "data": "StartDate",
            "render": function (data, type, row, meta) {
              var startdate = row.StartDate.split("/").reverse().join("-");
              return '<span style="display:none">' + startdate + '</span>' + row.StartDate + '';
            }
          },
          { data: "JobID" },
          { data: "JobTitle" },
          {
            data: "RecruiterEmailID",
            render: function (data, type, row, meta) {
              return '<a href="mailto:' + data + '">' + data + "</a>";
            }
          },
          { data: "Step" },
          { data: "Status" },
          { data: "InterimStatus" }
        ]
      });
      //drawing candidate table using dataTable

      //Enabling column filter for dataTable
      yadcf.init(oTable, [
        {
          column_number: 1,
          filter_type: "text"
        },
        {
          column_number: 2,
          filter_type: "text"
        },
        {
          column_number: 3,
          filter_type: "text"
        },
        {
          column_number: 4,
          filter_type: "text"
        },
        {
          column_number: 5,
          filter_type: "text"
        },
        {
          column_number: 6,
          filter_type: "text"
        },
        {
          column_number: 7,
          filter_type: "text"
        },
        {
          column_number: 8,

          filter_type: "date",
          date_format: "dd/mm/yyyy"
        },
        {
          column_number: 9,
          filter_type: "text"
        },
        {
          column_number: 10,
          filter_type: "text"
        },
        {
          column_number: 11,
          filter_type: "text"
        },
        {
          column_number: 12,
          filter_type: "multi_select",
          select_type: "select2"
        },
        {
          column_number: 13,
          filter_type: "multi_select",
          select_type: "select2"
        },
        {
          column_number: 14,
          filter_type: "multi_select",
          select_type: "select2"
        }
      ]);
      //Enabling column filter for dataTable

      var candidateDetailsUrl = baseUrl + "api/Candidate/GetCandidateDetail";

      // getting dropdown values for additional info
      $.ajax({
        type: "POST",
        url: additionalInfoUrl,
        //dataType: "json",
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        beforeSend: function () {
          $(".spinner-container").show();
        },
        data: JSON.stringify({
          UserID: loginDetails,
          Roles: roleType,
          key: "WorkLocation"
        }),
        success: function (response) {
          var titleRes = JSON.stringify(response);
          var titleData = JSON.parse(titleRes);
          $.each(titleData, function (index, value) {

            $("#workLocation").append(
              '<option value="' +
              value.DDLKeyValue +
              '">' +
              value.DDLKeyValue +
              "</option>"
            );
          });
        },
        complete: function () {
          $.ajax({
            type: "POST",
            url: additionalInfoUrl,
            //dataType: "json",
            contentType: "application/json",
            crossDomain: true,
            xhrFields: { withCredentials: true },
            data: JSON.stringify({
              UserID: loginDetails,
              Roles: roleType,
              key: "VisaRequired"
            }),
            success: function (response) {
              var titleRes = JSON.stringify(response);
              var titleData = JSON.parse(titleRes);
              $.each(titleData, function (index, value) {

                $("#workVisa").append(
                  '<option value="' +
                  value.DDLKeyValue +
                  '">' +
                  value.DDLKeyValue +
                  "</option>"
                );
              });
            },
            complete: function () {
              $.ajax({
                type: "POST",
                url: additionalInfoUrl,
                //dataType: "json",
                contentType: "application/json",
                crossDomain: true,
                xhrFields: { withCredentials: true },
                data: JSON.stringify({
                  UserID: loginDetails,
                  Roles: roleType,
                  key: "TypeofVisa"
                }),
                success: function (response) {
                  var titleRes = JSON.stringify(response);
                  var titleData = JSON.parse(titleRes);
                  $.each(titleData, function (index, value) {

                    $("#visaType").append(
                      '<option value="' +
                      value.DDLKeyValue +
                      '">' +
                      value.DDLKeyValue +
                      "</option>"
                    );
                  });
                },
                complete: function () {
                  $(".spinner-container").hide();
                },

                error: function (jqXHR, error, errorThrown) {
                  if (jqXHR.status == 401) {
                    $.alert({
                      icon: "fas fa-exclamation-circle fa-5x",
                      title: "",
                      theme: "my-theme",
                      content: "Session Timed Out",
                      buttons: {
                        ok: function () {

                          window.location.assign(accessUrl + "/Login.html");
                        }
                      }
                    });
                  } else if (jqXHR.status && jqXHR.status == 400) {
                    window.location.assign(accessUrl + "/502.html");
                  } else {
                    window.location.assign(accessUrl + "/502.html");
                  }
                }
              });
            },

            error: function (jqXHR, error, errorThrown) {
              if (jqXHR.status == 401) {
                $.alert({
                  icon: "fas fa-exclamation-circle fa-5x",
                  title: "",
                  theme: "my-theme",
                  content: "Session Timed Out",
                  buttons: {
                    ok: function () {

                      window.location.assign(accessUrl + "/Login.html");
                    }
                  }
                });
              } else if (jqXHR.status && jqXHR.status == 400) {
                window.location.assign(accessUrl + "/502.html");
              } else {
                window.location.assign(accessUrl + "/502.html");
              }
            }
          });
        },

        error: function (jqXHR, error, errorThrown) {
          if (jqXHR.status == 401) {
            $.alert({
              icon: "fas fa-exclamation-circle fa-5x",
              title: "",
              theme: "my-theme",
              content: "Session Timed Out",
              buttons: {
                ok: function () {

                  window.location.assign(accessUrl + "/Login.html");
                }
              }
            });
          } else if (jqXHR.status && jqXHR.status == 400) {
            window.location.assign(accessUrl + "/502.html");
          } else {
            window.location.assign(accessUrl + "/502.html");
          }
        }
      });
      // getting dropdown values for additional info

      // Setting previously updated values to the additional info modal
      $("#action").on("change", function () {
        var idx = oTable.cell(".selected", 1).index();
        if (idx) {
          var tblData = oTable.row(idx.row).data();

          var completeUrl =
            candidateDetailsUrl;

          if (tblData.CandidateID != null || tblData.CandidateID != "") {
            if ($(this).val() == 1) {
              if (roleType == "HROps") {
                alert("You can not access Add Additional Info");
                $(this).val(0);
              } else {
                $("#AdditionalInfo").modal("show");
                $.ajax({
                  type: "POST",
                  url: completeUrl,
                  //dataType:"json",
                  contentType: "application/json",
                  crossDomain: true,
                  xhrFields: { withCredentials: true },
                  data: JSON.stringify({
                    UserID: loginDetails,
                    Roles: roleType,
                    CandidateID: $("#CandidateId").val(),
                    JobID: $("#JobId").val(),
                    JobTitle: $("#JobTitle").val()
                  }),
                  success: function (response) {
                    var candiDeRes = JSON.stringify(response);
                    var candiDeData = JSON.parse(candiDeRes);

                    $.each(candiDeData, function (index, value) {

                      $("#workLocation").val(value.WorkLocation);
                      $("#workVisa").val(value.WorkVisaRequired);
                      $("#visaType").val(value.TypeOfVisa);
                      $("#hidStaffId").val(value.StaffID);
                      /*        if (value.StaffID == "" || value.StaffID == null) {
                               $("#idStaff").prop('readonly', false);
                             } else {
                               $("#idStaff").prop('readonly', true);
                             } */
                      $("#idStaff").val(value.StaffID);
                      if (value.WorkLocation == null || value.WorkLocation == "") {
                        $("#workLocation").val("0");
                        $("#workVisa, #visaType").val("");
                        $("#workVisa, #visaType").attr("disabled", true);
                      }
                      if (value.WorkVisaRequired == "No") {
                        $("#visaType").attr("disabled", true);
                      } else {
                        $("#visaType").attr("disabled", false);
                      }
                      if (value.WorkLocation == "Hong Kong") {
                        $("#workVisa").attr("disabled", false);
                      } else {
                        $("#workVisa, #visaType").attr("disabled", true);
                      }

                    });
                  }
                });

                $("#candidNum").val(tblData.CandidateID);
                $("#jobIdInfo").val(tblData.JobID);
                $("#jobTitleInfo").val(tblData.JobTitle);
              }
            } else $("#AdditionalInfo").modal("hide");
          }
        } else {
          $.alert({
            icon: "fas fa-exclamation-circle fa-5x",
            title: "",
            theme: "my-theme",
            content: "Please select a candidate to add/edit additional information."
          });

          $(this).val(0);
        }
      });
      // Setting previously updated values to the additional info modal

      $("#candidateTable_filter, #candidateTable_length").hide();

      // additional info form validation and post
      var validator = $("#additionalInfo").validate({
        rules: {
          workLocation: {
            required: true
          },
          workVisa: {
            required: true
          },
          visaType: {
            required: true
          },
          idStaff: {
            required: false,
            noSpace: true
          }
        },
        messages: {
          workLocation: {
            required: "Please select work location"
          },
          workVisa: {
            required: "Please Select work visa"
          },
          visaType: {
            required: "Please select visa type"
          },
          idStaff: {
            minlength: "please enter atleast 6 digits"
          }
        },
        errorElement: "em",
        errorPlacement: function (error, element) {
          error.addClass("help-block");
          if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
          } else {
            error.insertAfter(element);
          }
        },
        onfocusout: function (element) {
          this.element(element);
        },
        highlight: function (element, errorClass, validClass) {
          $(element)
            .parents(".form-group")
            .addClass("has-error")
            .removeClass("has-success");
        },
        unhighlight: function (element, errorClass, validClass) {
          $(element)
            .parents(".form-group")
            .addClass("has-success")
            .removeClass("has-error");
        },
        submitHandler: function (form) {
          let result;
          let candidId = $("#candidNum").val();
          let jobIdInfo = $("#jobIdInfo").val();
          let jobTitleInfo = $("#jobTitleInfo").val();
          let workLocation = $("#workLocation").val();
          let workVisa = $("#workVisa").val();
          let visaType = $("#visaType").val();
          let idStaff = $("#idStaff").val();
          if (idStaff != $("#hidStaffId").val()) {

            $.ajax({
              type: "POST",
              url: baseUrl + "api/Candidate/GetCandidateDocUDMSStat",
              //dataType:"json",
              contentType: "application/json",
              crossDomain: true,
              xhrFields: { withCredentials: true },
              beforeSend: function () {
                $(".spinner-container").show();
              },
              data: JSON.stringify({
                UserID: loginDetails,
                Roles: roleType
              }),
              success: function (response) {
                result = response.map(function (a) { return a.UdmsUploadStatus; });

              },
              complete: function () {
                $(".spinner-container").hide();
                if (result.indexOf("Selected for upload") > -1 ||
                  result.indexOf("Uploaded to UDMS") > -1 ||
                  result.indexOf("File already exists") > -1 ||
                  result.indexOf("Uploaded but not verified by Bot") > -1 ||
                  result.indexOf("Uploaded Manually") > -1
                ) {
                  $.alert({
                    icon: "fas fa-exclamation-circle fa-5x",
                    title: "",
                    theme: "my-theme",
                    content: "Warning! Some documents may be in the status of being processed. Please contact and confirm with HROps Team before proceeding. Do you want to continue?",
                    buttons: {
                      Yes: function () {
                        updateAddInfo(loginDetails, roleType, jobIdInfo, jobTitleInfo, candidId, workLocation, workVisa, visaType, idStaff);
                      },
                      No: function () {
                        return;
                      }
                    }
                  });
                } else {
                  updateAddInfo(loginDetails, roleType, jobIdInfo, jobTitleInfo, candidId, workLocation, workVisa, visaType, idStaff);
                }

              },
              error: function (jqXHR, error, errorThrown) {
                if (jqXHR.status == 401) {
                  $.alert({
                    icon: "fas fa-exclamation-circle fa-5x",
                    title: "",
                    theme: "my-theme",
                    content: "Session Timed Out",
                    buttons: {
                      ok: function () {

                        window.location.assign(accessUrl + "/Login.html");
                      }
                    }
                  });
                } else if (jqXHR.status && jqXHR.status == 400) {
                  window.location.assign(accessUrl + "/502.html");
                } else {
                  window.location.assign(accessUrl + "/502.html");
                }
              }
            });
          } else {
            updateAddInfo(loginDetails, roleType, jobIdInfo, jobTitleInfo, candidId, workLocation, workVisa, visaType, idStaff);
          }
        }
      });
      // additional info form validation and post

      // Enable disable dropdowns in additional info modal
      $("#workLocation").on("change", function () {
        if ($(this).val() == "Hong Kong") {
          $("#workVisa").attr("disabled", false);
        } else {
          $("#workVisa, #visaType").attr("disabled", true);
          $("#workVisa, #visaType").val("");
        }
      });

      $("#workVisa").on("change", function () {
        if ($(this).val() == "Yes") {
          $("#visaType").attr("disabled", false);
        } else {
          $("#visaType").attr("disabled", true);
          $("#visaType").val("");
        }
      });
      // Enable disable dropdowns in additional info modal

      // on closing additional info modal resetting form values
      $("#AdditionalInfo").on("hide.bs.modal", function (e) {
        $("#action").val("0");
        validator.resetForm();
        $("#additionalInfo .control-group").removeClass("error");
      });
    },
    complete: function () {
      setTimeout(checkSession, 8000);
    }
  });
});

function getDetails(id) {
  let jobID = $(id).parent().parent().find("td:eq(9)").text();
  let jobTitle = $(id).parent().parent().find("td:eq(10)").text();
  let candidateID = $(id).text();
  $.ajax({
    type: "POST",
    url: baseUrl + "api/Candidate/GetCookieDetails",
    //dataType: "json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    data: JSON.stringify({
      CandidateID: candidateID,
      JobID: jobID,
      JobTitle: jobTitle,
      Roles: $("#roleType").val(),
      UserID: $("#loginDetails").text()
    }),
    success: function (response) {
      window.location.href = "CandidateDetails.html";
    },
    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/Login.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });

}

$("#candidateTable").on('click', 'tr', function () {
  $('#CandidateId').val($(this).find("td:eq(2)").text());
  $('#JobId').val($(this).find("td:eq(9)").text());
  $('#JobTitle').val($(this).find("td:eq(10)").text());
  $.ajax({
    type: "POST",
    url: baseUrl + "api/Candidate/GetCookieDetails",
    //dataType: "json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    data: JSON.stringify({
      CandidateID: $(this).find("td:eq(2)").text(),
      JobID: $(this).find("td:eq(9)").text(),
      JobTitle: $(this).find("td:eq(10)").text(),
      Roles: $("#roleType").val(),
      UserID: $("#loginDetails").text()
    }),
    success: function (response) {
      console.log();
    },
    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/Login.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
});

function updateAddInfo(a, b, c, d, e, f, g, h, i) {
  $.ajax({
    type: "POST",
    url: baseUrl + "api/Candidate/UpdateCandidateDetail",
    //dataType:"json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    beforeSend: function () {
      $(".spinner-container").show();
    },
    data: JSON.stringify({
      UserID: a,
      Roles: b,
      Values: [
        {
          jobid: c,
          jobtitle: d,
          CandidateID: e,
          worklocation: f,
          WorkVisaRequired: g,
          typeofvisa: h,
          staffid: i
        }
      ]
    }),
    success: function (response) {
      $.alert({
        icon: "far fa-check-circle fa-5x",
        title: "",
        theme: "green-theme",
        content: "Additional info updated successfully.",
        buttons: {
          ok: function () {
            window.location.reload();
          }
        }
      });
    },
    complete: function () {
      $(".spinner-container").hide();
    },

    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/Login.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
}