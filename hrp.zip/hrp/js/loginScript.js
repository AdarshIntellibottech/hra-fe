$(document).ready(function () {
  $("#userName").focus();

  // Display an Information message for the browser Microsift Edge on iOS devices
  var userAgent = navigator.userAgent;

  if (userAgent.indexOf("EdgiOS") > -1) {
    $.alert({
      icon: "fas fa-exclamation-circle fa-5x",
      title: "",
      theme: "my-theme",
      content: "This portal is not fully supported by Microsoft Edge. Recommend using Chrome or Safari browser."
    });
  }

  //login form validation and post method
  $("#loginForm").validate({
    rules: {
      userName: {
        required: true,
        minlength: 4
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    messages: {
      userName: {
        required: "Please enter a username",
        minlength: "Your username must consist of at least 4 characters"
      }
    },
    password: {
      required: "Please provide a password",
      minlength: "Your password must be at least 5 characters long"
    },
    errorElement: "em",
    errorPlacement: function (error, element) {
      error.addClass("help-block");
      if ($(element).prop("type") === "checkbox") {
        error.insertAfter($(element).parent("label"));
      } else {
        error.insertAfter(element);
      }
    },
    highlight: function (element, errorClass, validClass) {
      $(element)
        .parents(".form-group")
        .addClass("has-error")
        .removeClass("has-success");
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element)
        .parents(".form-group")
        .addClass("has-success")
        .removeClass("has-error");
    },
    submitHandler: function (form) {
      var userName = $("#userName").val();
      var password = $("#password").val();
      $("#login_btn").hide();
      $(".animationStripes").show();
      $.ajax({
        type: "POST",
        url: baseUrl + "api/User/Login",
        dataType: "json",
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({ UserName: userName, Password: password }),
        success: function (response) {
          var res = JSON.parse(response);
          if (res.Status == "Success") {
            if (res.output_data.Role == "Admin") {
              window.location.href = accessUrl + "/UserList.html";
            } else {
              window.location.href = accessUrl + "/CandidateOfferList.html";
            }
            $("#login_btn").show();
            $("#recruiterAnimation").hide();
          } else {
            $.alert({
              icon: "fas fa-exclamation-circle fa-5x",
              title: "",
              theme: "my-theme",
              content: res.Message
            });

            $("#login_btn").show();
            $("#recruiterAnimation").hide();
          }
        },

        error: function (jqXHR, error, errorThrown) {
          if (jqXHR.status && jqXHR.status == 400) {
            window.location.assign(accessUrl + "/502.html");
          } else {
            window.location.assign(accessUrl + "/502.html");
          }
        }
      });
    }
  });

  //login form validation
  document.getElementById("email")
    .addEventListener("keyup", function (event) {
      event.preventDefault();
      if (event.keyCode === 13) {
        sendOtp();
      }
    });

  //Send OTP to candidate
  function sendOtp() {
    var id = $("#email").val();
    var req = $("#email").valid();
    if (req) {
      $("#candidateAnimation").show();
      $("#sendOTP")
        .removeClass("d-block")
        .addClass("d-none");
      $(this).attr("disabled", true);
      $.ajax({
        type: "POST",
        url: candBaseUrl + "api/User/OTPMail",
        dataType: "json",
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({ EmailID: id }),
        success: function (result) {
          var res = JSON.parse(result);
          if (res.Status == "Success") {
            $("#candidateAnimation").hide();
            var timer2 = "5:01";
            var interval = setInterval(function () {
              var timer = timer2.split(":");
              var minutes = parseInt(timer[0], 10);
              var seconds = parseInt(timer[1], 10);
              --seconds;
              minutes = seconds < 0 ? --minutes : minutes;
              seconds = seconds < 0 ? 59 : seconds;
              seconds = seconds < 10 ? "0" + seconds : seconds;
              $(".timer").html(minutes + ":" + seconds);
              if (minutes < 0) {
                clearInterval(interval);
                $(".resend").removeClass("d-none");
                $(".timer").html("");
              }
              if (seconds <= 0 && minutes <= 0) {
                clearInterval(interval);
                $(".resend").removeClass("d-none");
                $(".timer").html("");
              }
              timer2 = minutes + ":" + seconds;
            }, 1000);
            $("#displayOtp")
              .removeClass("d-none")
              .addClass("d-block");
            $("#sendOTP")
              .removeClass("d-block")
              .addClass("d-none");
            $("#candiate_login_btn")
              .removeClass("d-none")
              .addClass("d-block");
            $("#candidateAnimation").hide();
          } else {
            $.alert({
              icon: "fas fa-exclamation-circle fa-5x",
              title: "",
              theme: "my-theme",
              content: res.Message
            });
            $("#sendOTP")
              .removeClass("d-none")
              .addClass("d-block");
            $("#sendOTP").attr("disabled", false);
            $("#candiate_login_btn")
              .removeClass("d-block")
              .addClass("d-none");
            $("#candidateAnimation").hide();

          }
        },
        error: function (jqXHR, error, errorThrown) {
          if (jqXHR.status && jqXHR.status == 400) {
            window.location.assign(accessUrl + "/502.html");
          } else {
            window.location.assign(accessUrl + "/502.html");
          }
        }
      });
    } else {
      $(this).attr("disabled", false);
      $("#candiate_login_btn")
        .removeClass("d-block")
        .addClass("d-none");
    }
  }

  //Send OTP to candidate

  $("#sendOTP").on("click", function () {
    // $("#candidateAnimation").show();
    sendOtp();
  });

  //resend OTP to candidate
  $("#resendOTP").on("click", function () {
    $(this).removeClass("d-block").addClass("d-none");
    $("#candiate_login_btn")
      .removeClass("d-block")
      .addClass("d-none");
    $("#candidateAnimation").show();
    sendOtp();
  });


  //candidate form validation and post
  $("#candidateLoginForm").validate({
    rules: {
      email: {
        required: true,
        email: true,
        noSpace: true
      },
      otp: {
        required: true,
        noSpace: true
      }
    },
    messages: {
      email: {
        required:
          "Invalid Username. Please enter the Email ID of your candidate profile as the username.",
        email: "Please enter valid Email-Id"
      },
      otp: {
        required: "Please enter the one-time password"
      }
    },
    errorElement: "em",
    errorPlacement: function (error, element) {
      error.addClass("help-block");
      if ($(element).prop("type") === "checkbox") {
        error.insertAfter($(element).parent("label"));
      } else {
        error.insertAfter(element);
      }
    },
    highlight: function (element, errorClass, validClass) {
      $(element)
        .parents(".form-group")
        .addClass("has-error")
        .removeClass("has-success");
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element)
        .parents(".form-group")
        .addClass("has-success")
        .removeClass("has-error");
    },
    submitHandler: function (form) {
      var userName = $("#email").val();
      var otp = $("#otp").val();
      if (otp == "") {
        return false;
      }
      $("#candiate_login_btn")
        .removeClass("d-block")
        .addClass("d-none");
      $("#candidateAnimation").show();
      $.ajax({
        type: "POST",
        url: candBaseUrl + "api/User/Verifyotp",
        dataType: "json",
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({ EmailID: userName, OTPNumber: otp }),
        success: function (response) {
          var res = JSON.parse(response);

          if (res.Status == "Success") {
            window.location.href =
              accessUrl + "/privacyPolicy.html";
            $("#recruiterAnimation").hide();
          } else {
            $.alert({
              icon: "fas fa-exclamation-circle fa-5x",
              title: "",
              theme: "my-theme",
              content: res.Message
            });
            $("#candiate_login_btn")
              .removeClass("d-none")
              .addClass("d-block");
            $("#candidateAnimation").hide();
          }
        },

        error: function (jqXHR, error, errorThrown) {
          if (jqXHR.status && jqXHR.status == 400) {
            window.location.assign(accessUrl + "/502.html");
          } else {
            window.location.assign(accessUrl + "/502.html");
          }
        }
      });
    }
  });
});


