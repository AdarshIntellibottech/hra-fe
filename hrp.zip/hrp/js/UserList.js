$(document).ready(function () {

  $.ajax({
    type: "GET",
    url: baseUrl + "api/User/LoggedUserDetails",
    dataType: "json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    success: function (response) {
      let res = JSON.parse(response);
      $("#roleType").val(res.output_data[0]['Role']);
      $("#loginDetails").text(res.output_data[0]['UserID']);
    },

    complete: function () {

      var subDataUrl = baseUrl + "api/User/GetUser";

      $.ajax({
        type: "POST",
        url: subDataUrl,
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({
          UserID: $("#loginDetails").text(),
          Roles: $("#roleType").val()
        }),
        beforeSend: function () {
          $(".spinner-container").show();
        }
      }).done(function (data) {
        $(".spinner-container").hide();
        var oTable = $("#userTable").dataTable({
          aaData: data,
          scrollX: true,
          info: false,
          // searching: true,
          scrollX: true,
          ordering: true,
          lengthChange: false,

          columns: [
            { data: "FirstName" },
            { data: "LastName" },
            { data: "UserName" },
            { data: "EmailID" },
            { data: "UserRole" },
            {
              "data": "IsActive",
              "render": function (data, type, row) {
                if (data === true) {
                  return "<label class='switch'><input type='checkbox' class='checkbox' checked value='" + data + "' data-id='" + row.UserName + "'  /> <span class='slider round'> </span> </label>";
                } else {
                  return "<label class='switch'><input type='checkbox'  class='checkbox' value='" + data + "' data-id='" + row.UserName + "' /> <span class='slider round'></span> </label>";
                }
              }
            },
            {
              "data": "EditUserID",
              "render": function (data, type, row) {
                return "<a href='EditUser.html?userId=" + row.UserID + "' class='btn btn-axa'>EDIT</a>";
              }
            }

          ],
        })
          .yadcf([
            {
              column_number: 0,
              filter_type: "text"
            },
            {
              column_number: 1,
              filter_type: "text"
            },
            {
              column_number: 2,
              filter_type: "text"
            },
            {
              column_number: 3,
              filter_type: "text"
            },
            {
              column_number: 4,
              filter_type: "text"
            },
          ]);
        setTimeout(function () { oTable.fnAdjustColumnSizing(); }, 50)
      }).fail(function (jqXHR, textStatus) {
        if (jqXHR.status == 401) {
          $.alert({
            icon: "fas fa-exclamation-circle fa-5x",
            title: "",
            theme: "my-theme",
            content: "Session Timed Out",
            buttons: {
              ok: function () {

                window.location.assign(accessUrl + "/Login.html");
              }
            }
          });
        } else if (jqXHR.status && jqXHR.status == 400) {
          window.location.assign(accessUrl + "/502.html");
        } else {
          window.location.assign(accessUrl + "/502.html");
        }

      });

    }
  });


});

$(document).on('change', '.checkbox', function () {
  var thisId = $(this);
  var isChecked = $(this).val();
  var UserID = $(this).attr("data-id");

  if (this.checked) {
    var IsActive = true;
    $.alert({
      icon: "far fa-check-circle fa-5x",
      title: "",
      theme: "green-theme",
      content: "Are you sure you want to enable the user?",
      buttons: {
        Yes: function () {
          $(thisId).prop('checked', true);
          EnableDisableUser(UserID, IsActive);
        },
        No: function () {
          $(thisId).prop('checked', false);
          return;
        }
      }
    });
  } else {
    var IsActive = false;

    $.alert({
      icon: "fas fa-exclamation-circle fa-5x",
      title: "",
      theme: "my-theme",
      content: "Are you sure you want to disable the user?",
      buttons: {
        Yes: function () {
          $(thisId).prop('checked', false);
          EnableDisableUser(UserID, IsActive);
        },
        No: function () {
          $(thisId).prop('checked', true);
          return;

        }
      }
    });
  }
});


function EnableDisableUser(id, active) {
  var url = baseUrl + "api/User/EnableDisableUser";
  let data = {
    UserID: $("#loginDetails").text(),
    Roles: $("#roleType").val(),
    UserName: id,
    IsActive: active
  };
  $.ajax({
    type: "POST",
    url: url,
    dataType: "json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    data: JSON.stringify(data),
    beforeSend: function () {
      $(".spinner-container").removeClass("d-none");
    },
    success: function (response) {
      $(".spinner-container").addClass("d-none");
    },
    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/Login.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
}