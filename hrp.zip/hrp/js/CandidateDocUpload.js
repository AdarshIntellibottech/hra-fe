var globalArray = [],
  globalFileName = [], oldCheckDtatus = [], oldCheckVal = [];


function candidateInfo() {
  $("table tbody").html('');
  $("#uploadToPortal, #saveAsDraft, #discard").attr("data-check", false);
  $.ajax({
    type: "POST",
    url: candBaseUrl + "api/Candidate/CandidateInfo",
    //dataType: "json",
    contentType: "application/json",
    beforeSend: function () {
      $(".spinner-container").show();
    },
    crossDomain: true,
    xhrFields: { withCredentials: true },
    data: JSON.stringify({
      Roles: "Candidate",
    }),
    success: function (response) {

      $("#candidUploadNum").val(response.CandidateID);
      $("#jobIdUploadInfo").val(response.JobID);
      $("#jobTitleUploadInfo").val(response.JobTitle);
      $("#roleTitleUploadInfo").val("Candidate");
      $("#candidateStaffId").val(response.StaffID);
      $("#candidateName").val(response.CandidateName);
      $("#WorkVisaRequired").val(response.WorkVisaRequired);
      $("#loginName").text(response.CandidateFirstName + ' ' + response.CandidateLastName);
      $('#loginDetails').text(response.CandidateEmailID);
      $("#typeOfVisa").val(response.TypeOfVisa);
      if (
        $("#WorkVisaRequired").val() == "" ||
        $("#WorkVisaRequired").val() == "No"
      ) {
        $("#headingTwo")
          .parent()
          .hide();
      }
    },


    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/CandidateLogin.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    },
    complete: function () {
      var count = 0;
      $.ajax({
        type: "POST",
        url: candBaseUrl + "api/CheckList/GetCheckList",
        //dataType:"json",
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({
          UserID: $("#loginDetails").text(),
          Roles: "Candidate",
          canid: $("#candidUploadNum").val(),
          jobid: $("#jobIdUploadInfo").val(),
          jobtitle: $("#jobTitleUploadInfo").val(),
          rolename: "Candidate",
          typeofdocument: "Basic"
        }),
        success: function (response) {

          $.each(response, function (index, value) {
            count++;
            if (value.IfApplicable == "Y") {
              $("#collapseOne table").append(
                "<tr data-dociD='" +
                value.DocID +
                "' data-mandatory='" +
                value.Mandatory +
                "' data-file='n'><td>" +
                count +
                "</td><td data-doctype='" +
                value.DocType +
                "'><span style='background:yellow;padding:5px'>" +
                value.DocName +
                "</span><br/><span class='description' style='color:grey'>Note:" +
                value.DocDescription +
                "</span><div class='NAcheckDiv mt-2'><input type='checkbox' data-change='no' onclick='changeMandatory(this);docCheck(this);' value='' class='NACheck align-middle'><input type='hidden' value='' class='checkBoxStatus'> <span class='label'>Not Applicable</span></div></td><td style='vertical-align: bottom;'><span class='FNSelected'>File not selected</span></td><td><a href='#' onclick='downloadStandardForm(this); return false;'>" +
                value.StandardForm +
                "</a></td><td><a class='addCollab' data-dociD='" +
                value.DocID +
                "' style='font-size:12px;text-transform: none' href='#' onclick='openModal(this)'>Select File</a></td></tr>"
              );
            } else {
              $("#collapseOne table").append(
                "<tr data-dociD='" +
                value.DocID +
                "' data-mandatory='" +
                value.Mandatory +
                "' data-file='n'><td>" +
                count +
                "</td><td data-doctype='" +
                value.DocType +
                "'><span style='background:yellow;padding:5px'>" +
                value.DocName +
                "</span><br/><span class='description' style='color:grey'>Note:" +
                value.DocDescription +
                "</span></td><td style='vertical-align: bottom;'><span class='FNSelected'>File Not Selected</span></td><td><a href='#' onclick='downloadStandardForm(this); return false;'>" +
                value.StandardForm +
                "</a></td><td><a class='addCollab' data-dociD='" +
                value.DocID +
                "' style='font-size:12px;text-transform: none' href='#' onclick='openModal(this)'>Select File</a></td></tr>"
              );
            }

            $("tr[data-docid=CD1]").find("td:last a").css("visibility", "hidden");
          });
          let signed =
            "<span class='error-message d-none' style='color:#212529'>Please attach the Signed Employment Contract.</span>";
          let selfDec =
            "<br><span class='error-message d-none' style='color:#212529'>Please attach the Self Declaration Form.</span>";
          let declaration =
            "<br><span class='error-message d-none' style='color:#212529'>Please attach the declaration form. If it is not applicable to you, please select 'Not applicable'.</span>";
          let authorization =
            "<br><span class='error-message d-none' style='color:#212529'>Please attach the Authorization Form for Reference Check.</span>";
          let hkid =
            "<br><span class='error-message d-none' style='color:#212529'>Please attach a copy of your HKID Card. Please select 'Not applicable' if you are not a HK Permanent Resident and do not have a HKID card. </span>";
          let macauID =
            "<br><span class='error-message d-none' style='color:#212529'>Please attach a copy of your Macau ID card.</span>";
          let passport =
            "<br><span class='error-message d-none' style='color:#212529'>Please attach a copy of your passport if you are NOT a HK Permanent Resident. Please select 'Not applicable' if you are a HK Permanent Resident. </span>";

          $("tr[data-docid=CD2]")
            .find("td:eq(1)")
            .append(signed);
          $("a[data-docid=CD3]")
            .find("td:eq(1)")
            .append(selfDec);
          $("a[data-docid=CD4]")
            .find("td:eq(1)")
            .append(declaration);
          $("a[data-docid=CD5]")
            .find("td:eq(1)")
            .append(authorization);
          $("a[data-docid=CD6]")
            .find("td:eq(1)")
            .append(hkid);
          $("a[data-docid=CD7]")
            .find("td:eq(1)")
            .append(macauID);
          $("a[data-docid=CD8]")
            .find("td:eq(1)")
            .append(passport);
        },
        complete: function () {
          $.ajax({
            type: "POST",
            url: candBaseUrl + "api/CheckList/GetCheckList",
            //dataType:"json",
            contentType: "application/json",
            crossDomain: true,
            xhrFields: { withCredentials: true },
            data: JSON.stringify({
              UserID: $("#loginDetails").text(),
              Roles: "Candidate",
              canid: $("#candidUploadNum").val(),
              jobid: $("#jobIdUploadInfo").val(),
              jobtitle: $("#jobTitleUploadInfo").val(),
              rolename: "Candidate",
              typeofdocument: "Visa"
            }),
            success: function (response) {

              $.each(response, function (index, value) {
                count++;
                if (value.IfApplicable == "Y") {
                  $("#collapseTwo table").append(
                    "<tr  data-dociD='" +
                    value.DocID +
                    "' data-mandatory='" +
                    value.Mandatory +
                    "' data-file='n'><td>" +
                    count +
                    "</td><td data-doctype='" +
                    value.DocType +
                    "'><span style='background:yellow;padding:5px'>" +
                    value.DocName +
                    "<i class='fas fa-info fa-lg ml-2 tooltipDesc' style='cursor:pointer;color:#f07662' data-toggle='tooltip' data-placement='top' title='' data-original-title='" +
                    value.DocDescription +
                    "'></i></span><div class='NAcheckDiv mt-2'><input type='checkbox' ddata-change='no' value='' onclick='blockMandatory(this);docCheck(this)' class='NACheck align-middle'> <input type='hidden' value='' class='checkBoxStatus'> <span class='label'>Not Applicable</span></div></td><td style='vertical-align: bottom;'><span class='FNSelected'>File Not Selected</span></td><td><a href='#' onclick='downloadStandardForm(this); return false;'>" +
                    value.StandardForm +
                    "</a></td><td><a class='addCollab' data-dociD='" +
                    value.DocID +
                    "' style='font-size:12px;text-transform: none' href='#' onclick='openModal(this)'>Select File</a></td></tr>"
                  );
                } else {
                  $("#collapseTwo table").append(
                    "<tr  data-dociD='" +
                    value.DocID +
                    "' data-mandatory='" +
                    value.Mandatory +
                    "' data-file='n'><td>" +
                    count +
                    "</td><td data-doctype='" +
                    value.DocType +
                    "'><span style='background:yellow;padding:5px'>" +
                    value.DocName +
                    "<i class='fas fa-info fa-lg ml-2 tooltipDesc' style='cursor:pointer;color:#f07662' data-toggle='tooltip' data-html='true' data-placement='top' title='' data-original-title='" +
                    value.DocDescription +
                    "'></i></span></td><td style='vertical-align: bottom;'><span class='FNSelected'>File Not Selected</span></td><td><a href='#' onclick='downloadStandardForm(this); return false;'>" +
                    value.StandardForm +
                    "</a></td><td><a class='addCollab' data-dociD='" +
                    value.DocID +
                    "' style='font-size:12px;text-transform: none' href='#' onclick='openModal(this)'>Select File</a></td></tr>"
                  );
                }
              });
              let visaType = $("#typeOfVisa").val();
              let COE2 = $("tr[data-docid='COE2'] td:eq(1)").find("i").attr("data-original-title");
              let COE2Des = "<br><span class='descripton' style='color:grey'>Note:" + COE2 + "</span>";
              if (visaType == "New Application") {
                let NA1 = $("[data-docid='NA1']").parent().parent().find("td:eq(1) i").attr("data-original-title");
                let Nai = $("[data-docid='NA1']").parent().parent().find("td:eq(1) i");
                let NA2 = $("tr[data-docid='NA2']").find("td:eq(1) i").attr("data-original-title");
                let NA2Des = "<br><span class='descripton' style='color:grey'>Note:" + NA2 + "</span>";
                $(NA2Des).insertAfter("tr[data-docid='NA2'] td:eq(1) span:eq(0)");
                $("tr[data-docid='NA2'] td:eq(1)").find("i").remove();
                if (NA1.match(/[^\r\n]+/g)) {
                  let arrayOfLines = NA1.match(/[^\r\n]+/g);
                  console.log(arrayOfLines);
                  let multiRow = "" + arrayOfLines[0] + "<br>" + arrayOfLines[1] + "<br>" + arrayOfLines[2] + "<br>" + arrayOfLines[3] + "<br>" + arrayOfLines[4] + "<br>" + arrayOfLines[5] + "";
                  $(Nai).attr("data-original-title", multiRow);
                }
              } else if (visaType == "Change of Employer") {
                let COE1 = $("[data-docid='COE1']").parent().parent().find("td:eq(1) i").attr("data-original-title");
                let COE = $("[data-docid='COE1']").parent().parent().find("td:eq(1) i");
                $(COE2Des).insertAfter("tr[data-docid='COE2'] td:eq(1) span:eq(0)");
                $("tr[data-docid='COE2'] td:eq(1)").find("i").remove();
                if (COE1.match(/[^\r\n]+/g)) {
                  let COELines = COE1.match(/[^\r\n]+/g);
                  let COERow = "" + COELines[0] + "<br>" + COELines[1] + "<br>" + COELines[2] + "<br>" + COELines[3] + "<br>" + COELines[4] + "<br>" + COELines[5] + "";
                  $(COE).attr("data-original-title", COERow);
                }
              } else if (visaType == "Training") {
                let TR1 = $("[data-docid='TR1']").parent().parent().find("td:eq(1) i").attr("data-original-title");
                let TRI = $("[data-docid='TR1']").parent().parent().find("td:eq(1) i");
                $(COE2Des).insertAfter("tr[data-docid='COE2'] td:eq(1) span:eq(0)");
                $("tr[data-docid='COE2'] td:eq(1)").find("i").remove();
                if (TR1.match(/[^\r\n]+/g)) {
                  let TRLines = TR1.match(/[^\r\n]+/g);
                  let multiRow = "" + TRLines[0] + "<br>" + TRLines[1] + "<br>" + TRLines[2] + "<br>" + TRLines[3] + "<br>" + TRLines[4] + "<br>" + TRLines[5] + "";
                  $(TRI).attr("data-original-title", multiRow);
                }
              } else {
                console.log();
              }
            },
            complete: function () {
              $.ajax({
                type: "POST",
                url: candBaseUrl + "api/CheckList/GetCheckList",
                //dataType:"json",
                contentType: "application/json",
                crossDomain: true,
                xhrFields: { withCredentials: true },
                data: JSON.stringify({
                  UserID: $("#loginDetails").text(),
                  Roles: "Candidate",
                  canid: $("#candidUploadNum").val(),
                  jobid: $("#jobIdUploadInfo").val(),
                  jobtitle: $("#jobTitleUploadInfo").val(),
                  rolename: "Candidate",
                  typeofdocument: "Staff"
                }),
                success: function (response) {
                  $.each(response, function (index, value) {
                    count++;
                    if (value.IfApplicable == "Y") {
                      $("#collapseThree table").append(
                        "<tr data-dociD='" +
                        value.DocID +
                        "' data-mandatory='" +
                        value.Mandatory +
                        "' data-file='n'><td>" +
                        count +
                        "</td><td data-doctype='" +
                        value.DocType +
                        "'><span style='background:yellow;padding:5px'>" +
                        value.DocName +
                        "<i class='fas fa-info fa-lg ml-2 tooltipDesc' style='cursor:pointer;color:#f07662' data-toggle='tooltip' data-placement='top' title='' data-original-title='" +
                        value.DocDescription +
                        "'></i></span><div class='NAcheckDiv mt-2'><input type='checkbox' data-change='no' value='' onclick='blockMandatory(this);docCheck(this)' class='NACheck align-middle'> <input type='hidden' value='' class='checkBoxStatus'> <span class='label'>Not Applicable</span></div></td><td style='vertical-align: bottom;'><span class='FNSelected'>File Not Selected</span></td><td><a href='#' onclick='downloadStandardForm(this); return false;'>" +
                        value.StandardForm +
                        "</a></td><td><a class='addCollab' data-dociD='" +
                        value.DocID +
                        "' style='font-size:12px;text-transform: none' href='#' onclick='openModal(this)'>Select File</a></td></tr>"
                      );
                    } else {
                      $("#collapseThree table").append(
                        "<tr data-dociD='" +
                        value.DocID +
                        "' data-mandatory='" +
                        value.Mandatory +
                        "' data-file='n'><td>" +
                        count +
                        "</td><td data-doctype='" +
                        value.DocType +
                        "'><span style='background:yellow;padding:5px'>" +
                        value.DocName +
                        "<i class='fas fa-info fa-lg ml-2 tooltipDesc' style='cursor:pointer;color:#f07662' data-toggle='tooltip' data-placement='top' title='' data-original-title='" +
                        value.DocDescription +
                        "'></i></span></td><td style='vertical-align: bottom;'><span class='FNSelected'>File Not Selected</span></td><td><a href='#' onclick='downloadStandardForm(this); return false;'>" +
                        value.StandardForm +
                        "</a></td><td><a class='addCollab' data-dociD='" +
                        value.DocID +
                        "' style='font-size:12px;text-transform: none' href='#' onclick='openModal(this)'>Select File</a></td></tr>"
                      );
                    }
                  });
				  let SIFH20Des = "<br><span class='descripton' style='color:grey'>Note: This plan is NOT Tax Deductible.</span>";
				  $(SIFH20Des).insertAfter("tr[data-docid='SIFH20'] td:eq(1) span:eq(0)");
                  let SIFH9 = $("tr[data-docid='SIFH9'] td:eq(1)").find("i").attr("data-original-title");
                  let SIFH10 = $("tr[data-docid='SIFH10'] td:eq(1)").find("i").attr("data-original-title");
				  let SIFH19 = "Please select either Simple or Smart plan. You may visit www.principal.com.hk for more details. Part 2-4 MUST be completed.";
                  //let SIFH19 = $("tr[data-docid='SIFH19'] td:eq(1)").find("i").attr("data-original-title");
                  let SIFH9Des = "<br><span class='descripton' style='color:grey'>Note:" + SIFH9 + "</span>";
                  let SIFH10Des = "<br><span class='descripton' style='color:grey'>Note:" + SIFH10 + "</span>";
                  let SIFH19Des = "<br><span class='descripton' style='color:grey'>Note:" + SIFH19 + "</span>";
                  $(SIFH9Des).insertAfter("tr[data-docid='SIFH9'] td:eq(1) span:eq(0)");
                  $("tr[data-docid='SIFH9'] td:eq(1)").find("i").remove();
                  $(SIFH10Des).insertAfter("tr[data-docid='SIFH10'] td:eq(1) span:eq(0)");
                  $("tr[data-docid='SIFH10'] td:eq(1)").find("i").remove();
                  $(SIFH19Des).insertAfter("tr[data-docid='SIFH19'] td:eq(1) span:eq(0)");
				  $("tr[data-docid='SIFH19'] td:eq(1)").find("i").attr("data-original-title", "Eligible for all staff members aged 18 to 65 who have been employed by AXA for a minimum period of 60 days");
                  let documentId = $("tr[data-docid='SIFH19']")
                    .find("td:eq(3) a")
                    .text();

				  //$(SIFH20Des).insertAfter("tr[data-docid='SIFH20'] td:eq(1) span:eq(0)");
                  let documentCon = $("tr[data-docid='SIFH19']")
                    .find("td:eq(3)");

                  let StaffDocID = $("tr[data-docid='SIFM3']")
                    .find("td:eq(3) a")
                    .text();

                  let staffDoc = $("tr[data-docid='SIFM3']").find("td:eq(3)");

                  if (documentId.match(/[^\r\n]+/g)) {
                    let arrayOfLines = documentId.match(/[^\r\n]+/g);
                    let multiA =
                      "<a href='#' onclick='downloadStandardForm(this); return false;'>" +
                      arrayOfLines[0] +
                      "</a>";
                    $(documentCon)
                      .find("a")
                      .remove();
                    $(documentCon).append(multiA);
                  }
                  if (StaffDocID.match(/[^\r\n]+/g)) {
                    let arrayOfLines = StaffDocID.match(/[^\r\n]+/g);
                    let multiA =
                      "<a href='#' onclick='downloadStandardForm(this); return false;'>" +
                      arrayOfLines[0] +
                      "</a><br>";
                    $(staffDoc).find("a").remove();
                    $(staffDoc).append(multiA);
                  }
                },
                complete: function () {
                  $("a").each(function () {
                    if ($(this).text() == "N/A") {
                      $(this).text("");
                    }
                  });
                  $(".description").each(function () {
                    if ($(this).text() == "Note:") {
                      $(this).hide();
                    }
                  });

                  $(".tooltipDesc").each(function () {
                    if ($(this).attr("data-original-title") == "") {
                      $(this).hide();
                    }
                  });
                  let docuViewURL =
                    candBaseUrl +
                    "api/DocUpload/Viewdocuploadedlist";
                  //viewApi
                  $.ajax({
                    type: "POST",
                    url: docuViewURL,
                    //dataType:"json",
                    contentType: "application/json",
                    crossDomain: true,
                    xhrFields: { withCredentials: true },
                    data: JSON.stringify({
                      UserID: $("#loginDetails").text(),
                      Roles: "Candidate",
                      CandidateID: $("#candidUploadNum").val(),
                      JobID: $("#jobIdUploadInfo").val(),
                      JobTitle: $("#jobTitleUploadInfo").val()
                    }),
                    success: function (data) {
                      $.each(data, function (key, value) {
                        let fileMandatory = $("[data-docid]")
                          .map(function () {
                            return $(this).attr("data-docid");
                          })
                          .get()
                          .join(",");

                        let fileMandatoryArray = fileMandatory.split(",");
                        if (fileMandatoryArray.indexOf(value.DocID) > -1) {

                          let elem = $(
                            "#accordionExample table tbody td a[data-docid='" +
                            value.DocID +
                            "']"
                          ).parent().parent();



                          let fUpload = $(elem)
                            .find("td:eq(2)");

                          let a;

                          if (value.DocStatus == "Saved as Draft") {
                            a =
                              "<div id='draftedFile'>\
                              <i class='fas fa-download mr-2 fa-lg'  data-toggle='tooltip' data-placement='top' title='Download File' data-original-title='Download File' style='cursor:pointer' onclick='downloadFile(this)'></i>\
                              <a href='#' class='draftFile fileName' onclick='previewViewFile(this);'>\
                              <i class='far fa-file-pdf fa-lg text-danger mr-2'></i><span>" +
                              value.Filename +
                              "</a><b class='ml-2' style='cursor:pointer' onclick='deleteDraft(this)'> X </b></div>";
                          } else {
                            a =
                              "\
                              <i class='fas fa-download mr-2 fa-lg'  data-toggle='tooltip' data-placement='top' title='Download File' data-original-title='Download File' style='cursor:pointer' onclick='downloadFile(this)'></i>\
                              <a href='#' onclick='previewViewFile(this);'><i class='far fa-file-pdf fa-lg text-danger mr-2'></i><span>" +
                              value.Filename +
                              "</a>";
                          }

                          let appendedData;



                          appendedData =
                            "<tr data-mandatory='N' data-docid=" +
                            value.DocID +
                            " data-file='n'>\
                          <td style='border-top:none;'></td>\
                          <td style='border-top:none;' data-doctype='" +
                            value.DocType +
                            "'>" +
                            a +
                            "</td>\
                          <td style='border-top:none;'><span class='prevStatus'>" +
                            value.DocStatus +
                            "</span><input type='hidden' value='" + value.DocStatus + "' class='docStatusCheck'></td>\
                          <td style='border-top:none;'></td>\
                          <td style='border-top:none;'></td>\
                          </tr>";


                          let dataAppended = $(appendedData).insertAfter($(elem));
                          if ($(dataAppended).find("td:eq(1) span").text() == "") {
                            $(dataAppended).prev().find("td:eq(2)").html("<span class='prevStatus'>" + value.DocStatus + "</span>");
                            $(dataAppended).prev().find("td:eq(2)").append("<input type='hidden' value='" + value.DocStatus + "' class='docStatusCheck'>");
                            $(dataAppended).remove();
                            $("#uploadToPortal").attr("disabled", false);
                            $(elem).find(".NACheck").parent().show();
                          } else {
                            $(elem).find(".NACheck").parent().hide();
                          }

                          if (value.Filename != "" && $(dataAppended).find("td:eq(2) span.prevStatus").text() == "Saved as Draft") {
                            $(elem).next("tr").attr("data-file", "y");
                          } else if (value.NotApplicableChecked != null && $(dataAppended).find("td:eq(2) span.prevStatus").text() == "Saved as Draft") {
                            $(elem).attr("data-file", "y");
                          } else {
                            $(elem).attr("data-file", "n");
                          }

                          if (value.NotApplicableChecked == "yes" || value.NotApplicableChecked == "no") {
                            // $(elem).find("td:eq(2)").css("visibility", "hidden");
                            // $(elem).find(".NACheck").parent().show();
                            if (value.NotApplicableChecked == "no") {
                              if ($(elem).attr('data-docid') == $(elem).next().attr('data-docid')) {
                                $(elem).find(".NACheck").parent().remove();
                                $(elem).find("td:eq(2)").empty();


                              }

                              $(elem).find(".NACheck").attr("checked", false);
                              $(elem).find(".NACheck").val(value.NotApplicableChecked);
                              // $(elem).find(".NACheck").parent().hide();
                              $(elem).find("td:last-child a").show();
                              $(elem).find(".NACheck").attr("onclick", "blockMandatory(this);docCheck(this)");
                              $(elem).find(".NACheck").next().val("no");
                            } else {
                              $(elem).find(".NACheck").next().val("yes");
                              $(elem).find(".NACheck").attr("checked", true);
                              $(elem).find(".NACheck").val(value.NotApplicableChecked);
                              $(elem).find("td:last-child a").hide();
                              $(elem).find(".NACheck").attr("onclick", "blockMandatory(this);docCheck(this)");
                              $(elem).css("color", "#cacaca");
                              let colour = $(elem).find(".description").parent().parent().css('color');
                              if (colour == "rgb(202, 202, 202)") {
                                $(elem).find(".description").css("color", "#cacaca");
                              }
                            }
                          } else {
                            $(elem).find(".NACheck").parent().hide();
                            $(elem).find(".NACheck").attr("checked", false);
                            $(elem).find(".NACheck").val(value.NotApplicableChecked);
                          }
							if(value.DocStatus == "Saved as Draft"){
								   $(fUpload)
                              .find(".FNSelected")
                              .hide();
								  $(elem)
                            .find("td:eq(1) span:eq(0)").css("background", "yellow");}
                          else if (
                            value.DocStatus != "" ||
                            value.DocStatus != null
                          ) {
                            $(fUpload)
                              .find(".FNSelected")
                              .hide();
								  $(elem)
                            .find("td:eq(1) span").css("background", "white");
								  
                          } else {
								   $(elem)
                            .find("td:eq(1) span").css("background", "yellow");
								  }
                          $(elem).attr("data-mandatory", "N");
                          let trElem = $(elem)
                            .next()
                            .attr("data-docid");
                          let elemDocId = $(elem).attr("data-docid");

                          if (trElem == elemDocId) {
                            $(elem).css("color", "#212529");
                            // $(elem).find("td:eq(1) span:eq(0)").css("color", "#212529");
                            // $(elem).find("td:eq(1) span:eq(1)").css("color", "#333333");
                            $(elem).find("td:eq(1) input")
                              .parent()
                              .hide();

                            $(elem).show();
                          }
								  
								/*  if(!$(elem).find(".NACheck").is(":checked")){
								  $(elem).find("td:eq(1) span:eq(0)").css('background-color', 'yellow')
								  } */
								 
								  $(".docUpload tbody tr:eq(0) td:eq(1) span").css('background-color', 'white')

                          let enableCheckArray = []
                          for (var i = 0; i < $("table tbody tr").length; i++) {
                            enableCheckArray.push($("table tbody tr:eq(" + i + ")").find("td:eq(2)").text());
                            enableCheckArray.join(",");
                          }
                          if (enableCheckArray.indexOf("Saved as Draft") > -1) {
                            $("#uploadToPortal").attr("disabled", false);
                            $("#saveAsDraft, #discard").attr("disabled", true);
                          } else {
                            $("#saveAsDraft, #discard, #uploadToPortal").attr("disabled", true);
                          }

                          //   if ($(".draftFile").length > 0) {

                          //     $("#uploadToPortal").attr(
                          //       "disabled",
                          //       false
                          //     );
                          //     $("#saveAsDraft, #discard").attr(
                          //       "disabled",
                          //       true
                          //     );
                          //   } else if ($(".draftFile").length == 0) {

                          //     $("#uploadToPortal").attr(
                          //       "disabled",
                          //       true
                          //     );
                          //     $("#saveAsDraft, #discard").attr(
                          //       "disabled",
                          //       true
                          //     );
                          //   } else {

                          //     $("#uploadToPortal").attr(
                          //       "disabled",
                          //       true
                          //     );
                          //     $("#saveAsDraft, #discard").attr(
                          //       "disabled",
                          //       false
                          //     );
                          //   }
                        }
                      });
                      oldCheckDtatus = [], oldCheckVal = [];
                      for (var i = 0; i < $("table tbody tr").length; i++) {
                        let updatedStatus = $("table tbody tr:eq(" + [i] + ") td:eq(2)").text();
                        let oldCheckedValue = $("table tbody tr:eq(" + [i] + ") td:eq(1)").find(".NACheck").val();
                        oldCheckDtatus.push(updatedStatus);
                        oldCheckVal.push([oldCheckedValue, updatedStatus]);
                        oldCheckDtatus.join(",");
                        oldCheckVal.join(",");

                      }
                    }
                  })
                    .done(function () {
                      $.ajax({
                        type: "POST",
                        url: candBaseUrl + "api/DocUpload/GetNumbers",
                        //dataType: "json",
                        contentType: "application/json",
                        crossDomain: true,
                        xhrFields: { withCredentials: true },
                        data: JSON.stringify({
                          UserID: $("#loginDetails").text(),
                          Roles: "Candidate",
                          CanEmailID: $("#loginDetails").text()
                        }),
                        success: function (response) {
                          $("#Dilm").val(response.Dilm);
                          $("#Dklm").val(response.Dklm);
                        },
                        complete: function () {
                          $.ajax({
                            type: "GET",
                            url: baseUrl + "api/Candidate/GetPrivacy",
                            dataType: "json",
                            contentType: "application/json",
                            crossDomain: true,
                            xhrFields: { withCredentials: true },
                            success: function (response) {
                              let res = JSON.parse(response);
                              if (res.Message == "Accepted") {
                                return;
                              }
                              else if (res.Message == "Declined") {
                                window.location.href = accessUrl + "/privacyDec.html";
                              }
                              else {
                                return;
                              }
                              console.log(response);
                            }
                          });
                          $('[data-toggle="tooltip"]').tooltip();
                          $(".spinner-container").hide();
                          setTimeout(checkSession, 8000);
                        },


                        error: function (jqXHR, error, errorThrown) {
                          if (jqXHR.status == 401) {
                            $.alert({
                              icon: "fas fa-exclamation-circle fa-5x",
                              title: "",
                              theme: "my-theme",
                              content: "Session Timed Out",
                              buttons: {
                                ok: function () {

                                  window.location.assign(accessUrl + "/CandidateLogin.html");
                                }
                              }
                            });
                          } else if (jqXHR.status && jqXHR.status == 400) {
                            window.location.assign(accessUrl + "/502.html");
                          } else {
                            window.location.assign(accessUrl + "/502.html");
                          }
                        }
                      });
                    });

                  //viewApi
                },

                error: function (jqXHR, error, errorThrown) {
                  if (jqXHR.status == 401) {
                    $.alert({
                      icon: "fas fa-exclamation-circle fa-5x",
                      title: "",
                      theme: "my-theme",
                      content: "Session Timed Out",
                      buttons: {
                        ok: function () {

                          window.location.assign(accessUrl + "/CandidateLogin.html");
                        }
                      }
                    });
                  } else if (jqXHR.status && jqXHR.status == 400) {
                    window.location.assign(accessUrl + "/502.html");
                  } else {
                    window.location.assign(accessUrl + "/502.html");
                  }
                }
              });
            },

            error: function (jqXHR, error, errorThrown) {
              if (jqXHR.status == 401) {
                $.alert({
                  icon: "fas fa-exclamation-circle fa-5x",
                  title: "",
                  theme: "my-theme",
                  content: "Session Timed Out",
                  buttons: {
                    ok: function () {

                      window.location.assign(accessUrl + "/CandidateLogin.html");
                    }
                  }
                });
              } else if (jqXHR.status && jqXHR.status == 400) {
                window.location.assign(accessUrl + "/502.html");
              } else {
                window.location.assign(accessUrl + "/502.html");
              }
            }
          });
        },

        error: function (jqXHR, error, errorThrown) {
          if (jqXHR.status == 401) {
            $.alert({
              icon: "fas fa-exclamation-circle fa-5x",
              title: "",
              theme: "my-theme",
              content: "Session Timed Out",
              buttons: {
                ok: function () {

                  window.location.assign(accessUrl + "/CandidateLogin.html");
                }
              }
            });
          } else if (jqXHR.status && jqXHR.status == 400) {
            window.location.assign(accessUrl + "/502.html");
          } else {
            window.location.assign(accessUrl + "/502.html");
          }
        }
      });
    }
  });
}

$(document).ready(function () {
  candidateInfo();

  $('#previewDocUpload').on('hidden.bs.modal', function () {
    $(this).find("a").remove();
  });

  var globalData = "";

  $("#collapseOne").on("hidden.bs.collapse", function () {
    $(".collOne")
      .find("i")
      .removeClass("fa-chevron-down")
      .addClass("fa-chevron-up");
  });
  $("#collapseOne").on("shown.bs.collapse", function () {
    $(".collOne")
      .find("i")
      .removeClass("fa-chevron-up")
      .addClass("fa-chevron-down");
  });

  $("#collapseTwo").on("hidden.bs.collapse", function () {
    $(".collTwo")
      .find("i")
      .removeClass("fa-chevron-down")
      .addClass("fa-chevron-up");
  });
  $("#collapseTwo").on("shown.bs.collapse", function () {
    $(".collTwo")
      .find("i")
      .removeClass("fa-chevron-up")
      .addClass("fa-chevron-down");
  });
  $("#collapseThree").on("hidden.bs.collapse", function () {
    $(".collThree")
      .find("i")
      .removeClass("fa-chevron-down")
      .addClass("fa-chevron-up");
  });
  $("#collapseThree").on("shown.bs.collapse", function () {
    $(".collThree")
      .find("i")
      .removeClass("fa-chevron-up")
      .addClass("fa-chevron-down");
  });
});
$(".inputDnD")
  .on("drag dragstart dragend dragover dragenter dragleave drop", function (
    event
  ) {
    event.preventDefault();
    event.stopPropagation();
  })
  .on("dragover dragenter", function () {
    $(this).addClass("is-dragover");
  })
  .on("dragleave dragend drop", function () {
    $(this).removeClass("is-dragover");
  })
  .on("drop", function (event) {
    // No idea if this is the right way to do things
    $("input[type=file]").prop("files", event.originalEvent.dataTransfer.files);
    $("input[type=file]").trigger("change");
  });
function isInArray(value, array) {
  return array.indexOf(value) > -1;
}
var fileArray = [];
var fileCount = 0;
function readUrl(input, mode) {
  var i;
  let backupArray = [];
  for (i = 0; i < input.files.length; i++) {
    var fsize = input.files[i].size / 1024 / 1024,
      ftype = input.files[i].type,
      fname = input.files[i].name,
      fFormat = fname.split(".").pop(),
      fextension = fname.substring(fname.lastIndexOf(".") + 1),
      aaFiles = input.files[i];
    fFormat = fFormat.toUpperCase();
    if (mode == "onUpload") {
      var existsOrNot = isInArray(aaFiles.name, globalFileName);
      if (existsOrNot == true) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "You cannot upload same document again."
        });

        return;
      }
    }
    validExtensions = [
      "jpg",
      "JPG",
      "pdf",
      "PDF",
      "jpeg",
      "JPEG",
      "tiff",
      "TIFF",
      "TIF",
      "tif",
      "gif",
      "GIF",
      "png",
      "PNG",
      "doc",
      "DOC",
      "docx",
      "DOCX"
    ];

    if ($.inArray(fextension, validExtensions) == -1) {
      $.alert({
        icon: "fas fa-exclamation-circle fa-5x",
        title: "",
        theme: "my-theme",
        content: "Please upload a file in .pdf / .docx/ .doc/ .jpg/ .jpeg/ .tif/ .png formats."
      });

      $(input).val("");
      return false;
    } else if (fsize > 10) {
      $.alert({
        icon: "fas fa-exclamation-circle fa-5x",
        title: "",
        theme: "my-theme",
        content: "File size exceeds 10MB. Please ensure the file size is less than 10 MB."
      });

      $(input).val("");
      return false;
    } else {
      fileArray.push([fname, fFormat]);
      fileArray.join(",");
      let data1 = fileArray.every(function (x) {
        return fileArray[0][1] === x[1];
      });
      if (data1 == false) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content:
            "If you would like to attach multiple pages/files, please attach files of the same format"
        });
        backupArray = globalFileName;
        array = backupArray.concat(globalFileName);
        globalFileName = [];
        // globalArray = [];
        fileArray = [];
        globalFileName = arrayUnique(array);
        $(input).val("");
        return false;
      }
      array = backupArray.concat(globalFileName);
      globalFileName = arrayUnique(array);

      function arrayUnique(array) {
        var a = array.concat();
        for (var i = 0; i < a.length; ++i) {
          for (var j = i + 1; j < a.length; ++j) {
            if (a[i] === a[j])
              a.splice(j--, 1);
          }
        }

        return a;
      }
      let file = input.files[i];
      globalArray[fileCount] = input.files[i];
      globalFileName[fileCount] = input.files[i].name;
      fileCount++;
      var reader = new FileReader();
      var crypt;
      reader.readAsArrayBuffer(file);
      reader.onload = function (e) {
        var key = CryptoJS.enc.Utf8.parse($("#Dklm").val());
        var iv = CryptoJS.enc.Utf8.parse($("#Dilm").val());
        var arrayBuffer = e.target.result;
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          function arrayBufferToBase64(arrayBuffer) {
            var binary = '';
            var bytes = new Uint8Array(arrayBuffer);
            var len = bytes.byteLength;
            for (var i = 0; i < len; i++) {
              binary += String.fromCharCode(bytes[i]);
            }
            return window.btoa(binary);
          };
          var base64 = arrayBufferToBase64(arrayBuffer);
          // var base64 = btoa(String.fromCharCode.apply(null, new Uint8Array(arrayBuffer)));
        } else {
          var base64 = btoa(
            new Uint8Array(arrayBuffer).reduce(function (data, byte) {
              return data + String.fromCharCode(byte);
            }, "")
          );
        }
        crypt = CryptoJS.AES.encrypt(base64, key, {
          keySize: 256 / 8,
          iv: iv,
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7
        });
        $("#encVal").val(crypt);
        passKey($("#encVal").val());
      };

      function passKey(crypt) {
        $.ajax({
          type: "POST",
          url: candBaseUrl + "api/DocUpload/UploadDocument",
          //dataType: "json",
          processData: false,
          contentType: "application/json",
          beforeSend: function () {
            $(".spinner-container").show();
          },
          crossDomain: true,
          xhrFields: { withCredentials: true },
          data: JSON.stringify({
            UserID: $("#loginDetails").text(),
            Roles: "Candidate",
            CanEmailID: $("#loginDetails").text(),
            Dklm: $("#Dklm").val(),
            Dilm: $("#Dilm").val(),
            FileName: file.name,
            UploadString: crypt
          }),
          success: function (response) {
            $(input).val("");
          },

          complete: function () {
            $(".spinner-container").hide();
          },

          error: function (jqXHR, error, errorThrown) {
            if (jqXHR.status == 401) {
              $.alert({
                icon: "fas fa-exclamation-circle fa-5x",
                title: "",
                theme: "my-theme",
                content: "Session Timed Out",
                buttons: {
                  ok: function () {

                    window.location.assign(accessUrl + "/CandidateLogin.html");
                  }
                }
              });
            } else if (jqXHR.status && jqXHR.status == 400) {
              window.location.assign(accessUrl + "/502.html");
            } else {
              window.location.assign(accessUrl + "/502.html");
            }
          }
        });
      }
    }
  }
  let newglobalFileName = globalFileName.filter(function (e) {
    return String(e).trim();
  });
  listFiles(newglobalFileName);
}

function listFiles(globalFileName) {
  var globalFileNameLength = globalFileName.length;
  var text = "";
  for (var j = 0; j < globalFileNameLength; j++) {
    var fileCount1 = j + 1;
    text =
      text +
      '<li><span class="styleList w-50 d-inline-block mr-3">' +
      globalFileName[j] +
      "</span>" +
      "<span class='mx-2 font-italic' style='font-size:0.8em'>File " +
      fileCount1 +
      " of " +
      globalFileNameLength +
      "</span><span class='delNode' onclick='deleteNode(this, " +
      j +
      ")'>X</span></li>";
  }
  $("#appendedListCandid")
    .empty()
    .append(text);
}

function deleteNode(id, dCount) {
  let li = id.parentNode;
  let fileName = li.children[0].innerHTML;

  $.ajax({
    type: "POST",
    url: candBaseUrl + "api/DocUpload/DeleteTempFile",
    //dataType: "json",
    contentType: "application/json",
    beforeSend: function () {
      $(".spinner-container").show();
    },
    crossDomain: true,
    xhrFields: { withCredentials: true },
    data: JSON.stringify({
      UserID: $("#loginDetails").text(),
      Roles: "Candidate",
      CanEmailID: $("#loginDetails").text(),
      FileName: fileName
    }),
    success: function (response) {
      id.parentNode.parentNode.removeChild(id.parentNode);
      for (var i = 0; i <= fileArray.length - 1; i++) {
        if (fileArray[i][0] == fileName) {
          fileArray.splice(i--, 1);
        }
      }

      globalArray.splice(dCount, 1);
      globalFileName.length = 0;
      fileCount--;
      for (var q = 0; q < globalArray.length; q++) {
        globalFileName[q] = globalArray[q].name;
      }
      listFiles(globalFileName);
    },
    complete: function () {
      $(".spinner-container").hide();
    },

    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/CandidateLogin.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
}


function cancelFile(input) {
  let naCheck = [];

  $("#appendedListCandid li .styleList").each(function () {
    naCheck.push($(this).text());
    return naCheck;
  })

  if (naCheck != "") {
    $.ajax({
      type: "POST",
      url: baseUrl + "api/DocUpload/CancelButton",
      //dataType: "json",
      contentType: "application/json",
      crossDomain: true,
      xhrFields: { withCredentials: true },
      beforeSend: function () {
        $(".spinner-container").show();
      },
      data: JSON.stringify({
        UserID: $("#loginDetails").text(),
        Roles: "Candidate",
        CanEmailID: $("#loginDetails").text(),
        FileName: naCheck,
      }),
      success: function (response) {
        if (response.Status == "Success") {
          return;
        }
      },
      complete: function () {
        $(".spinner-container").hide();
      },
      error: function (jqXHR, error, errorThrown) {
        if (jqXHR.status == 401) {
          $.alert({
            icon: "fas fa-exclamation-circle fa-5x",
            title: "",
            theme: "my-theme",
            content: "Session Timed Out",
            buttons: {
              ok: function () {

                window.location.assign(accessUrl + "/CandidateLogin.html");
              }
            }
          });
        } else if (jqXHR.status && jqXHR.status == 400) {
          window.location.assign(accessUrl + "/502.html");
        } else {
          window.location.assign(accessUrl + "/502.html");
        }
      }
    });
  }

}

function discardFile(input) {
  $(input).attr('data-check', true);

  $.ajax({
    type: "POST",
    url: baseUrl + "api/DocUpload/Discard",
    //dataType: "json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    beforeSend: function () {
      $(".spinner-container").show();
    },
    data: JSON.stringify({
      UserID: $("#loginDetails").text(),
      Roles: "Candidate",
      CanEmailID: $("#loginDetails").text()

    }),
    success: function (response) {
      if (response.Status == "Success") {
        $.alert({
          icon: "far fa-check-circle fa-5x",
          title: "",
          theme: "green-theme",
          content: "Unsaved file(s) discarded successfully",
          buttons: {
            ok: function () {
              // window.location.reload();
              candidateInfo();
            }
          }
        });
      }
    },
    complete: function () {
      $(".spinner-container").hide();
    },

    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/CandidateLogin.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
}

function openModal(elem) {
  event.preventDefault();
  let draft = $(elem).parent().parent().attr("data-docid");
  for (var i = 0; i < $("table tbody tr[data-docid]").length; i++) {
    let everyDraft = $(
      "table tbody tr[data-docid='" + draft + "']:eq(" + i + ")"
    ).find(".fileName");
    if (everyDraft.length > 0) {
      $.alert({
        icon: "fas fa-exclamation-circle fa-5x",
        title: "",
        theme: "my-theme",
        content:
          "If you would like to add another file, please delete the attached file by clicking on 'X' icon."
      });

      return;
    }
  }
  let draftRow = $(elem)
    .parent()
    .prev()
    .prev()
    .prev()
    .find(".fileName");
  if (draftRow.length > 0) {
    $.alert({
      icon: "fas fa-exclamation-circle fa-5x",
      title: "",
      theme: "my-theme",
      content:
        "If you would like to add another file, please delete the attached file by clicking on 'X' icon."
    });
  } else {
    let a = elem.getAttribute("data-docid");
    let label =
      elem.parentNode.previousSibling.previousSibling.previousSibling
        .children[0].innerHTML;
    document.getElementById("labelheadUpload").innerHTML = label;
    $("#referenceUpload").val(a);
    $("#inputFileUpload").val("");
    $(".inputDnD label").text("Drag and drop file \u000A OR \u000A Browse");
    $("#appendedListCandid")
      .find("li")
      .remove();
    $("#appendedListCandid").empty();
    globalArray.length = 0;
    globalFileName.length = 0;
    fileCount = 0;
    fileArray = [];
    $("#uploadModalCandid").modal("show");
  }
}

function deleteDraft(id) {
  let fileDraft = $(id)
    .parent()
    .find(".draftFile span")
    .text();
  $.ajax({
    type: "POST",
    url: candBaseUrl + "api/DocUpload/DeleteDraft",
    //dataType: "json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    beforeSend: function () {
      $(".spinner-container").show();
    },
    data: JSON.stringify({
      UserID: $("#loginDetails").text(),
      Roles: "Candidate",
      FileName: fileDraft,
      JobID: $("#jobIdUploadInfo").val(),
      JobTitle: $("#jobTitleUploadInfo").val(),
      CanEmailID: $("#loginDetails").text()
    }),
    success: function (response) {
      $(id)
        .parent()
        .remove();
      $.alert({
        icon: "far fa-check-circle fa-5x",
        title: "",
        theme: "green-theme",
        content: "Draft deleted successfully.",
        buttons: {
          ok: function () {
            // window.location.reload();
            candidateInfo();
          }
        }
      });
    },
    complete: function () {
      $(".spinner-container").hide();
    },

    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/CandidateLogin.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
}

function mergedDocuments(input) {
  if (fileArray.length == 1) {
    common();
  } else {
    var data1 = fileArray.every(function (x) {
      return fileArray[0][1] === x[1];
    });

    if (data1 == false) {
      $.alert({
        icon: "fas fa-exclamation-circle fa-5x",
        title: "",
        theme: "my-theme",
        content:
          "If you would like to attach multiple pages/files, please attach files of the same format"
      });

      return false;
    } else {
      common();
    }
  }
}

function changeMandatory(id) {
  let parent = id.parentNode.parentNode.parentNode;
  let modal =
    id.parentNode.parentNode.nextElementSibling.nextElementSibling
      .nextElementSibling.children;
  if (id.checked) {
    parent.setAttribute("data-mandatory", "N");
    parent.style.color = "#cacaca";
    $(id)
      .parent()
      .parent()
      .find(".error-message")
      .removeClass("d-block")
      .addClass("d-none");
    $(id)
      .parent()
      .parent()
      .next()
      .find(".FNSelected")
      .hide();
    $(id)
      .parent()
      .parent()
      .find("span")
      .first()
      .css("color", "#cacaca");
    $(parent)
      .find("td:eq(1) span:eq(1)")
      .css("color", "#cacaca");
    $(id)
      .next()
      .css("color", "#cacaca");
    $(id)
      .parent()
      .parent()
      .next()
      .css("color", "#cacaca");
		    $(id)
      .parent()
      .parent()
      .find("span")
      .first()
      .css("background", "white");
    let td = parent.children[0];
    let elem = td.children;
    modal[0].style.display = "none";
  } else {
    parent.setAttribute("data-mandatory", "Y");
    modal[0].style.display = "block";

    parent.style.color = "#212529";
    $(id)
      .parent()
      .parent()
      .next()
      .find(".FNSelected")
      .show();
    $(id)
      .parent()
      .parent()
      .find("span")
      .first()
      .css("color", "#212529");
								  		    $(id)
      .parent()
      .parent()
      .find("span")
      .first()
      .css("background", "yellow");
    $(id)
      .next()
      .css("color", "#212529");
    $(id)
      .parent()
      .parent()
      .next()
      .css("color", "#212529");
    $(parent)
      .find("td:eq(1) span:eq(1)")
      .css("color", "#333333");
  }
}

function blockMandatory(id) {
  let parent = id.parentNode.parentNode.parentNode;
  let modal =
    id.parentNode.parentNode.nextElementSibling.nextElementSibling
      .nextElementSibling.children;
  if (id.checked) {
    parent.style.color = "#cacaca";

    $(id)
      .parent()
      .parent()
      .next()
      .find(".FNSelected")
      .hide();
    $(id)
      .parent()
      .parent()
      .find("span")
      .first()
      .css("color", "#cacaca");
	    $(id)
      .parent()
      .parent()
      .find("span")
      .first()
      .css("background", "white");
    $(parent)
      .find("td:eq(1) span:eq(1)")
      .css("color", "#cacaca");
    $(id)
      .next()
      .css("color", "#cacaca");
    $(id)
      .parent()
      .parent()
      .next()
      .css("color", "#cacaca");
    let td = parent.children[0];
    let elem = td.children;
    modal[0].style.display = "none";
  } else {
    modal[0].style.display = "block";

    parent.style.color = "#212529";
    $(id)
      .parent()
      .parent()
      .next()
      .find(".FNSelected")
      .show();
    $(id)
      .parent()
      .parent()
      .find("span")
      .first()
      .css("color", "#212529");
		    $(id)
      .parent()
      .parent()
      .find("span")
      .first()
      .css("background", "yellow");
    $(id)
      .next()
      .css("color", "#212529");
    $(id)
      .parent()
      .parent()
      .next()
      .css("color", "#212529");
    $(parent)
      .find("td:eq(1) span:eq(1)")
      .css("color", "#333333");
  }
}

function arraysEqual(array1, array2) {
  if (!Array.isArray(array1) && !Array.isArray(array2)) {
    return array1 === array2;
  }

  if (array1.length !== array2.length) {
    return false;
  }

  for (var i = 0, len = array1.length; i < len; i++) {
    if (!arraysEqual(array1[i], array2[i])) {
      return false;
    }
  }

  return true;
}

let docCheckcount = 0;
function docCheck(checkbox) {
  let newCheckedStatus = [], newCheckVal = [], yesCheckedStatus = [], yesCheckVal = [];
  let docId = $(checkbox).parent().parent().parent().attr("data-docid");
  let nextVal = $(checkbox).parent().parent().next().find(".docStatusCheck").val();
  $(checkbox).attr('data-change', "yes");
  if ($(checkbox).is(':checked')) {
    docCheckcount++;
    $(checkbox).val("yes");
    let checkVal = $(checkbox).val();
    let checkNextVal = $(checkbox).next().val();
    if (checkVal == checkNextVal && nextVal == "Saved as Draft") {
      $(checkbox).parent().parent().parent().attr("data-file", "y");
    } else if (checkVal == checkNextVal) {
      $(checkbox).parent().parent().parent().attr("data-file", "n");
      $(checkbox).parent().parent().parent().attr("data-checking", "n");
    } else {
      $(checkbox).parent().parent().parent().attr("data-file", "y");
      $(checkbox).parent().parent().parent().attr("data-checking", "y");
    }
    if (nextVal == undefined || nextVal == "") {
      $(checkbox).parent().parent().next().text("Not Applicable");
    } else {
      $(checkbox).parent().parent().next().find(".prevStatus").text(nextVal);
    }
    for (var i = 0; i < $("table tbody tr").length; i++) {
      let yesCheckedValue = $("table tbody tr:eq(" + [i] + ") td:eq(2)").text();
      let yesCheckedStat = $("table tbody tr:eq(" + [i] + ") td:eq(1)").find(".NACheck").val();
      yesCheckedStatus.push(yesCheckedValue);
      yesCheckVal.push([yesCheckedStat, yesCheckedValue]);
      yesCheckedStatus.join(",");
      yesCheckVal.join(",");

    }

    if (yesCheckedStatus.indexOf("Not Applicable") > -1) {
      $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', false);
    } else if (!arraysEqual(oldCheckVal, yesCheckVal)) {
      $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', false);
    } else if (oldCheckDtatus.indexOf("Saved as Draft") > -1) {
      $("#uploadToPortal").prop('disabled', false);
      $("#discard, #saveAsDraft").prop('disabled', true);
    } else {
      $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', true);
    }
    // $(checkbox).parent().parent().next().text("Not Applicable");
    //  $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', false);
  } else {
    if (nextVal == undefined || nextVal == "") {
      $(checkbox).val("");
    } else {
      $(checkbox).val("no");
    }
    if (docId == "CD4" || docId == "CD6" || docId == "CD8") {
      $(checkbox).parent().parent().parent().attr("data-mandatory", "Y");
    }
    let checkVal1 = $(checkbox).val();
    let checkNextVal1 = $(checkbox).next().val();
    if (checkVal1 == checkNextVal1 && nextVal == "Saved as Draft") {
      $(checkbox).parent().parent().parent().attr("data-file", "y");
    } else if (checkVal1 == checkNextVal1) {
      $(checkbox).parent().parent().parent().attr("data-file", "n");
      $(checkbox).parent().parent().parent().attr("data-checking", "n");
    } else {
      $(checkbox).parent().parent().parent().attr("data-file", "y");
      $(checkbox).parent().parent().parent().attr("data-checking", "y");
    }
    if (nextVal == undefined || nextVal == "") {
      $(checkbox).parent().parent().next().text("File Not Selected");
    } else {
      $(checkbox).parent().parent().next().find(".prevStatus").text(nextVal);
    }
    for (var i = 0; i < $("table tbody tr").length; i++) {
      let newCheckedValue = $("table tbody tr:eq(" + [i] + ") td:eq(2)").text();
      let newCheckedStat = $("table tbody tr:eq(" + [i] + ") td:eq(1)").find(".NACheck").val();
      newCheckedStatus.push(newCheckedValue);
      newCheckVal.push([newCheckedStat, newCheckedValue]);
      newCheckedStatus.join(",");
      newCheckVal.join(",");

    }
    if (newCheckedStatus.indexOf("Not Applicable") > -1) {
      $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', false);
    } else if (!arraysEqual(oldCheckVal, newCheckVal)) {
      $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', false);
    } else if (oldCheckDtatus.indexOf("Saved as Draft") > -1) {
      $("#uploadToPortal").prop('disabled', false);
      $("#discard, #saveAsDraft").prop('disabled', true);
    } else {
      $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', true);
    }
    //  $(elem).attr("data-mandatory", "N");



  }
}

/* let doUncheckCount = 0;
function doUncheck(checkmark) {
  let newCheckedStatus = [];
  let docId = $(checkmark).parent().parent().parent().attr("data-docid");

  let status = $(checkmark).parent().parent().next().text();
  $(checkmark).attr('data-change', 'yes');
  if ($(checkmark).is(':checked')) {
    doUncheckCount--;
    $(checkmark).val("yes");
    $(checkmark).parent().parent().next().text(status);
    for (var i = 0; i < $("table tbody tr").length; i++) {
      let newCheckedValue = $("table tbody tr:eq(" + [i] + ") td:eq(2)").text();
      newCheckedStatus.push(newCheckedValue);
      newCheckedStatus.join(",");
    }
    if (oldCheckDtatus.indexOf("Saved as Draft") > -1) {
      $("#uploadToPortal").prop('disabled', false);
      $("#discard, #saveAsDraft").prop('disabled', true);
    } else if (newCheckedStatus.indexOf("Not Applicable") > -1) {
      $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', false);
    } else {
      $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', true);
    }
    $(checkmark).parent().parent().next().text("Not Applicable");
    // $(checkmark).parent().parent().next().css("visibility", "hidden");
  } else {

    $(checkmark).val("no");
    if (docId == "CD4" || docId == "CD6" || docId == "CD8") {
      $(checkmark).parent().parent().parent().attr("data-mandatory", "Y");
    }
    $(checkmark).parent().parent().next().text("File Not Selected ");
    $("#discard, #saveAsDraft, #uploadToPortal").prop('disabled', false);
    // $(checkmark).parent().parent().next().css("visibility", "visible");
    doUncheckCount++;

  }
} */

function allBlanks(arr) {
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] !== "") return false;
  }

  return true;
}
function uploadPortal(uploadInput) {
  let rowI = [];
  function validArray(my_arr) {
    for (var i = 0; i < my_arr.length; i++) {
      if (my_arr[i] === "Y") return false;
    }
    return true;
  }
  let mandat = $("[data-mandatory]")
    .map(function () {
      return $(this).attr("data-mandatory");
    })
    .get()
    .join(",");
  let mandatArray = mandat.split(",");
  let valid = $("tbody tr[data-mandatory='Y']");

  if (validArray(mandatArray) == false) {
    $.alert({
      icon: "fas fa-exclamation-circle fa-5x",
      title: "",
      theme: "my-theme",
      content: "Kindly attach all highlighted BASIC DOCUMENTS in RED or select Not Applicable to continue."
    });

    $(valid)
      .find("td")
      .css("color", "#f07662");
    $(valid)
      .parents(".collapse")
      .addClass("show");
    $(valid)
      .find(".error-message")
      .removeClass("d-none")
      .addClass("d-block");
  } else {
    $.confirm({
      icon: "far fa-check-circle fa-5x",
      title: "",
      theme: "green-theme",
      content:
        "Are you sure you want to upload all the files that are attached or saved as draft ?",
      buttons: {
        Yes: function () {
          var uploadPortal = {
            UserID: $("#loginDetails").text(),
            Roles: "Candidate",
            CanEmailID: $("#loginDetails").text(),
            Values: []
          };

          let docTypeArray = [];
          let docIdArray = [];
          let fileNameArray = [];
          let fileMandatoryArray = [];
          let ApplicableCheckedArray = [];
          let docStatusArray = [];

          for (var i = 0; i < $("table tbody tr[data-file='y']").length; i++) {
            let docType = $("table tbody tr[data-file='y']:eq(" + [i] + ") td:eq(1)").attr("data-doctype");
            let docStatus = $("table tbody tr[data-file='y']:eq(" + [i] + ") td:eq(2)").text();
            let docId = $("table tbody tr[data-file='y']:eq(" + [i] + ")").attr("data-docid");

            let fileName = $("table tbody tr[data-file='y']:eq(" + [i] + ") td:eq(1)").find(
              ".fileName"
            );
            let fileMandatory = $("table tbody tr[data-file='y']:eq(" + [i] + ")").attr(
              "data-mandatory"
            );
            let naCheck = $("table tbody tr[data-file='y']:eq(" + [i] + ") td:eq(1)").find(
              ".NACheck"
            );


            if (docStatus == undefined || docStatus == "File Not Selected") {
              docStatusArray.push("");
            } else if (docStatus == "Not Applicable") {
              docStatusArray.push("File uploaded");
            } else if (docStatus == "File Attached") {
              docStatusArray.push("File uploaded");
            } else {
              docStatusArray.push(docStatus);
              docStatusArray.join(",");
            }
            if (docType == undefined) {
              docTypeArray.push("");
            } else {
              docTypeArray.push(docType);
              docTypeArray.join(",");
            }

            docIdArray.push(docId);
            docIdArray.join(",");
            if (docIdArray[i] == undefined) {
              docIdArray[i] = "";
            }

            if (fileName == "") {
              fileNameArray.push("");
            } else {
              fileNameArray.push($(fileName).text());
              fileNameArray.join(",");
            }
            if (fileNameArray[i] == $("#candidUploadNum").val() + "_") {
              fileNameArray[i] = "";
            }

            if (fileMandatory == undefined) {
              fileMandatoryArray.push("");
            } else {
              fileMandatoryArray.push(fileMandatory);
              fileMandatoryArray.join(",");
            }

            if (naCheck == undefined) {
              ApplicableCheckedArray.push(null);
            } else {
              ApplicableCheckedArray.push($(naCheck).val());
              ApplicableCheckedArray.join(",");
            }
            if (ApplicableCheckedArray[i] == undefined) {
              ApplicableCheckedArray[i] = null;
            }


            if ((ApplicableCheckedArray[i] == "no" && docStatusArray[i] == "File uploaded" && fileNameArray[i] == undefined) ||
              (ApplicableCheckedArray[i] == "no" && docStatusArray[i] == "File uploaded" && fileNameArray[i] == "")) {
              rowI.push(i);
              rowI.join(",");
            }

            uploadPortal.Values.push({
              JobID: $("#jobIdUploadInfo").val(),
              JobTitle: $("#jobTitleUploadInfo").val(),
              StaffID: $("#candidateStaffId").val(),
              CandidateID: $("#candidUploadNum").val(),
              DocID: docIdArray[i],
              DocType: docTypeArray[i],
              Filename: $.trim(fileNameArray[i]),
              FileType: "pdf",
              DocStatus: "File uploaded",
              NotApplicableChecked: ApplicableCheckedArray[i],
              IfApplicable: fileMandatoryArray[i],
              CreatedBy: $("#candidateName").val(),
              FileVersion: "1"
            });
          }

          if (rowI.length > 0) {
            $.alert({
              icon: "fas fa-exclamation-circle fa-5x",
              title: "",
              theme: "my-theme",
              content: "Kindly attach file for highlighted row."
            });
            $("table tbody tr[data-file='y'][data-checking='y']").css("color", "red");
            $("table tbody tr[data-file='y'][data-checking='y']").find("td:eq(1) span").css("color", "red");
            $("table tbody tr[data-file='y'][data-checking='y']").find("td:eq(2) span").css("color", "red");
            return;

          }

          $.ajax({
            type: "POST",
            url: candBaseUrl + "api/DocUpload/InsertDocDetails",
            //dataType:"json",
            contentType: "application/json",
            beforeSend: function () {
              $(".spinner-container").show();
            },
            crossDomain: true,
            xhrFields: { withCredentials: true },
            data: JSON.stringify(uploadPortal),
            success: function (response) {
              $(uploadInput).attr("data-check", "true");
              $.alert({
                icon: "far fa-check-circle fa-5x",
                title: "",
                theme: "green-theme",
                content: "File(s) uploaded successfully",
                buttons: {
                  ok: function () {
                    // window.location.reload();
                    candidateInfo();
                  }
                }
              });
            },
            complete: function () {
              $(".spinner-container").hide();
            },
            error: function (jqXHR, error, errorThrown) {
              if (jqXHR.status == 401) {
                $.alert({
                  icon: "fas fa-exclamation-circle fa-5x",
                  title: "",
                  theme: "my-theme",
                  content: "Session Timed Out",
                  buttons: {
                    ok: function () {

                      window.location.assign(accessUrl + "/CandidateLogin.html");
                    }
                  }
                });
              } else if (jqXHR.status && jqXHR.status == 400) {
                window.location.assign(accessUrl + "/502.html");
              } else {
                window.location.assign(accessUrl + "/502.html");
              }
            }
          });
        },
        No: function () {
          return;
        }
      }
    });
  }
}

function draftPortal(uploadInput) {
  let rowI = [];
  var uploadPortal = {
    UserID: $("#loginDetails").text(),
    Roles: "Candidate",
    CanEmailID: $("#loginDetails").text(),
    Values: []
  };

  let docTypeArray = [];
  let docIdArray = [];
  let fileNameArray = [];
  let fileMandatoryArray = [];
  let ApplicableCheckedArray = [];
  let docStatusArray = [];
  for (var i = 0; i < $("table tbody tr[data-file='y']").length; i++) {
    let docStatus = $("table tbody tr[data-file='y']:eq(" + [i] + ") td:eq(2)").text();
    let docType = $("table tbody tr[data-file='y']:eq(" + [i] + ") td:eq(1)").attr(
      "data-doctype"
    );
    let docId = $("table tbody tr[data-file='y']:eq(" + [i] + ")").attr("data-docid");
    console.log(docId);
    let fileName = $("table tbody tr[data-file='y']:eq(" + [i] + ") td:eq(1)").find(
      ".fileName"
    );
    let fileMandatory = $("table tbody tr[data-file='y']:eq(" + [i] + ")").attr(
      "data-mandatory"
    );
    let naCheck = $("table tbody tr[data-file='y']:eq(" + [i] + ") td:eq(1)").find(".NACheck");

    if (docStatus == undefined || docStatus == "File Not Selected") {
      docStatusArray.push("");
    } else if (docStatus == "Not Applicable") {
      docStatusArray.push("Saved as Draft");
    } else if (docStatus == "File Attached") {
      docStatusArray.push("Saved as Draft");
    } else {
      docStatusArray.push(docStatus);
      docStatusArray.join(",");
    }
    if (docType == undefined) {
      docTypeArray.push("");
    } else {
      docTypeArray.push(docType);
      docTypeArray.join(",");
    }

    docIdArray.push(docId);
    docIdArray.join(",");
    if (docIdArray[i] == undefined) {
      docIdArray[i] = "";
    }

    if (fileName == "") {
      fileNameArray.push("");
    } else {
      fileNameArray.push($(fileName).text());
      fileNameArray.join(",");
    }
    if (fileNameArray[i] == $("#candidUploadNum").val() + "_") {
      fileNameArray[i] = "";
    }

    if (fileMandatory == undefined) {
      fileMandatoryArray.push("");
    } else {
      fileMandatoryArray.push(fileMandatory);
      fileMandatoryArray.join(",");
    }

    if (naCheck == undefined) {
      ApplicableCheckedArray.push(null);
    } else {
      ApplicableCheckedArray.push($(naCheck).val());
      ApplicableCheckedArray.join(",");
    }
    if (ApplicableCheckedArray[i] == undefined) {
      ApplicableCheckedArray[i] = null;
    }


    if ((ApplicableCheckedArray[i] == "no" && docStatusArray[i] == "File uploaded" && fileNameArray[i] == undefined) ||
      (ApplicableCheckedArray[i] == "no" && docStatusArray[i] == "File uploaded" && fileNameArray[i] == "")) {
      rowI.push(i);
      rowI.join(",");
    }

    uploadPortal.Values.push({
      JobID: $("#jobIdUploadInfo").val(),
      JobTitle: $("#jobTitleUploadInfo").val(),
      StaffID: $("#candidateStaffId").val(),
      CandidateID: $("#candidUploadNum").val(),
      DocID: docIdArray[i],
      DocType: docTypeArray[i],
      Filename: $.trim(fileNameArray[i]),
      FileType: "pdf",
      DocStatus: "Saved as Draft",
      NotApplicableChecked: ApplicableCheckedArray[i],
      IfApplicable: fileMandatoryArray[i],
      CreatedBy: $("#candidateName").val(),
      FileVersion: "1"
    });
  }

  if (rowI.length > 0) {
    $.alert({
      icon: "fas fa-exclamation-circle fa-5x",
      title: "",
      theme: "my-theme",
      content: "Kindly attach file for highlighted row."
    });
    $("table tbody tr[data-file='y'][data-checking='y']").css("color", "red");
    $("table tbody tr[data-file='y'][data-checking='y']").find("td:eq(1) span").css("color", "red");
    $("table tbody tr[data-file='y'][data-checking='y']").find("td:eq(2) span").css("color", "red");

    return;

  }

  $.ajax({
    type: "POST",
    url: candBaseUrl + "api/DocUpload/InsertDocDetails",
    //dataType:"json",
    contentType: "application/json",
    beforeSend: function () {
      $(".spinner-container").show();
    },
    crossDomain: true,
    xhrFields: { withCredentials: true },
    data: JSON.stringify(uploadPortal),
    success: function (response) {
      $(uploadInput).attr("data-check", "true");
      $.alert({
        icon: "far fa-check-circle fa-5x",
        title: "",
        theme: "green-theme",
        content: "File(s) saved as draft successfully",
        buttons: {
          ok: function () {
            // window.location.reload();
            candidateInfo();
          }
        }
      });
    },
    complete: function () {
      $(".spinner-container").hide();
    },

    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/CandidateLogin.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
}
function previewTempFile(input) {
  event.preventDefault();
  $("#previewDocFrameUpload").attr("src", "");
  var file = $(input).text();

  var settings = {
    async: true,
    crossDomain: true,
    url: candBaseUrl + "api/DocUpload/Preview",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    },
    beforeSend: function () {
      $(".spinner-container").show();
    },
    processData: false,
    crossDomain: true,
    xhrFields: { withCredentials: true },
    data: JSON.stringify({
      UserID: $("#loginDetails").text(),
      Roles: "Candidate",
      FileName: file + ".pdf",
      CanEmailID: $("#loginDetails").text()
    })
  };

  $.ajax(settings).done(function (response) {
    $("#Dklm").val(response.Dklm);
    $("#Dilm").val(response.Dilm)
    var key = CryptoJS.enc.Utf8.parse($("#Dklm").val());
    var iv = CryptoJS.enc.Utf8.parse($("#Dilm").val());
    function decrypt(crypt, key) {
      var decrypted = CryptoJS.AES.decrypt(crypt, key, {
        iv: iv,
        padding: CryptoJS.pad.Pkcs7,
        mode: CryptoJS.mode.CBC
      })
      return decrypted;
    }
    var dec = decrypt(response.TextValue, key);
    var base64str = dec.toString(CryptoJS.enc.Utf8);

    var binary = atob(base64str.replace(/\s/g, ''));
    var len = binary.length;
    var buffer = new ArrayBuffer(len);
    var view = new Uint8Array(buffer);
    for (var i = 0; i < len; i++) {
      view[i] = binary.charCodeAt(i);
    }

    var blob = new Blob([view], { type: "application/pdf" });
    var url = window.URL.createObjectURL(blob);

    var ua = window.navigator.userAgent;
    var isIE = /MSIE|Trident/.test(ua);
    var isSafari = navigator.vendor && navigator.vendor.indexOf('Apple') > -1 &&
      navigator.userAgent &&
      navigator.userAgent.indexOf('CriOS') == -1 &&
      navigator.userAgent.indexOf('FxiOS') == -1;

    if (isIE) {
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        let blob = new Blob([view], { type: "application/pdf" });
        let staffId = $("#candidateStaffId").val();
        let label = $(input).text();
        var label1 = label.split('_');
        if (staffId == "") {
          file = label1[1] + ".pdf";
        } else {
          file = staffId + "_" + label1[1] + ".pdf";;
        }
        window.navigator.msSaveOrOpenBlob(blob, file);
      }

    } else if (isSafari || ua.indexOf("EdgA/") > -1) {
      var a = document.createElement("a");
      a.href = url;
      let staffId = $("#candidateStaffId").val();
      let label = $(input).text();
      let label1 = label.split('_');
      if (staffId == "") {
        a.download = label1[1];
        a.click();
      } else {
        a.download = staffId + "_" + label1[1];
        a.click();
      }
      window.URL.revokeObjectURL(url);
      //return false;
    } else {
      $("#previewDocUpload")
        .find(".modal-title")
        .text(file);
      $("#previewDocFrameUpload").attr("src", "");
      $("#previewDocFrameUpload").attr("src", url + "#toolbar=0");
      $("#previewDocFrameUpload").css({
        width: "100%",
        height: "400px"
      });
      let label = $("#previewDocLabel").text();
      let label1 = label.split("_");
      let staffId = $("#ssLast p:eq(3)").find("span").text();
      let aTag;
      if (staffId == "") {
        aTag = $("<a class='btn btn-axa pr-1' data-toggle='tooltip' data-placement='top' title='Download File' data-original-title='Download File'><i class='fas fa-download mr-2 fa-lg' style='cursor:pointer'></i></a>").attr({
          "href": url,
          "download": label1[1] + "_" + label1[2]
        });
      } else {
        aTag = $("<a class='btn btn-axa pr-1' data-toggle='tooltip' data-placement='top' title='Download File' data-original-title='Download File'><i class='fas fa-download mr-2 fa-lg' style='cursor:pointer'></i></a>").attr({
          "href": url,
          "download": staffId + "_" + label1[1] + "_" + label1[2]
        });
      }

      aTag.insertAfter($("#previewDocFrame"));
      $('[data-toggle="tooltip"]').tooltip();
      $("#previewDocUpload").modal("show");
    }
    $(".spinner-container").hide();
    //window.URL.revokeObjectURL(url);
  });
}
function previewViewFile(input) {
  event.preventDefault();
  var file = $(input)
    .find("span")
    .text();

  var settings = {
    async: true,
    url: candBaseUrl + "api/DocUpload/DownloadFile",
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "cache-control": "no-cache"
    },
    beforeSend: function () {
      $(".spinner-container").show();
    },
    crossDomain: true,
    xhrFields: { withCredentials: true },
    processData: false,
    data: JSON.stringify({
      UserID: $("#loginDetails").text(),
      Roles: "Candidate",
      FileName: file,
      CanEmailID: $("#loginDetails").text()
    })
  };

  $.ajax(settings).done(function (response) {
    $("#Dklm").val(response.Dklm);
    $("#Dilm").val(response.Dilm);

    var key = CryptoJS.enc.Utf8.parse($("#Dklm").val());
    var iv = CryptoJS.enc.Utf8.parse($("#Dilm").val());
    function decrypt(crypt, key) {
      var decrypted = CryptoJS.AES.decrypt(crypt, key, {
        iv: iv,
        padding: CryptoJS.pad.Pkcs7,
        mode: CryptoJS.mode.CBC
      });
      return decrypted;
    }
    var dec = decrypt(response.TextValue, key);
    var base64str = dec.toString(CryptoJS.enc.Utf8);

    var binary = atob(base64str.replace(/\s/g, ""));
    var len = binary.length;
    var buffer = new ArrayBuffer(len);
    var view = new Uint8Array(buffer);
    for (var i = 0; i < len; i++) {
      view[i] = binary.charCodeAt(i);
    }

    var blob = new Blob([view], { type: "application/pdf" });
    var url = window.URL.createObjectURL(blob);

    var ua = window.navigator.userAgent;
    var userAgent = navigator.userAgent || navigator.vendor || window.opera;
    var isIE = /MSIE|Trident/.test(ua);
    var isSafari = navigator.vendor && navigator.vendor.indexOf('Apple') > -1 &&
      navigator.userAgent &&
      navigator.userAgent.indexOf('CriOS') == -1 &&
      navigator.userAgent.indexOf('FxiOS') == -1;
    if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)) { //Safari & Opera iOS

      let url = window.URL.createObjectURL(blob);
      window.location.href = url;
    }
    else if (isSafari || ua.indexOf("EdgA/") > -1) {
      // alert();
      var a = document.createElement("a");
      a.href = url;
      let staffId = $("#candidateStaffId").val();
      let label = $(input).text();
      let label1 = label.split('_');
      if (staffId == "") {
        a.download = label1[1] + "_" + label1[2];
        a.click();
      } else {
        a.download = staffId + "_" + label1[1] + "_" + label1[2];
        a.click();
      }

      window.URL.revokeObjectURL(url);
      // return false;
    }

    else if (isIE) {
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        let staffId = $("#candidateStaffId").val();
        let label = $(input).text();
        var label1 = label.split('_');
        if (staffId == "") {
          file = label1[1] + "_" + label1[2];
        } else {
          file = staffId + "_" + label1[1] + "_" + label1[2];
        }
        let blob = new Blob([view], { type: "application/pdf" });
        window.navigator.msSaveOrOpenBlob(blob, file);
      }

    } else {
      $("#previewDocUpload")
        .find(".modal-title")
        .text(file);
      $("#previewDocFrameUpload").attr("src", "");
      $("#previewDocFrameUpload").attr("src", url + "#toolbar=0");
      $("#previewDocFrameUpload").css({
        width: "100%",
        height: "400px"
      });
      let label = $("#previewDocLabel").text();
      let label1 = label.split('_');
      let staffId = $("#candidateStaffId").val();
      let aTag;
      if (staffId == "") {
        aTag = $("<a class='btn btn-axa pr-1' data-toggle='tooltip' data-placement='top' title='Download File' data-original-title='Download File'><i class='fas fa-download mr-2 fa-lg' style='cursor:pointer'></i></a>").attr({
          "href": url,
          "download": label1[1] + "_" + label1[2]
        });
      } else {
        aTag = $("<a class='btn btn-axa pr-1' data-toggle='tooltip' data-placement='top' title='Download File' data-original-title='Download File'><i class='fas fa-download mr-2 fa-lg' style='cursor:pointer'></i></a>").attr({
          "href": url,
          "download": staffId + "_" + label1[1] + "_" + label1[2]
        });
      }

      aTag.insertAfter($("#previewDocFrameUpload"));
      $('[data-toggle="tooltip"]').tooltip();
      $("#previewDocUpload").modal("show");
    }
    $(".spinner-container").hide();
    //window.URL.revokeObjectURL(url);
  });
}

function deleteMerged(input) {
  let a = $(input).parent();
  let fileName = $(a)
    .find(".fileName")
    .text();

  $.ajax({
    type: "POST",
    url: candBaseUrl + "api/DocUpload/DeleteMergedFile",
    //dataType: "json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    beforeSend: function () {
      $(".spinner-container").show();
    },
    data: JSON.stringify({
      UserID: $("#loginDetails").text(),
      Roles: "Candidate",
      CanEmailID: $("#loginDetails").text(),
      FileName: fileName + ".pdf"
    }),

    success: function (response) {
      $(input).parent().parent().parent().attr("data-file", "n");
      $(input)
        .parent()
        .parent()
        .next()
        .find(".FAttached")
        .remove();
      $(input)
        .parent()
        .parent()
        .find(".NACheck")
        .parent()
        .show();

      $(input)
        .parent()
        .parent()
        .next()
        .find(".FNSelected")
        .show();

      $(a)
        .parent()
        .parent()
        .attr("data-mandatory", "");
      $(a).parent().parent().attr("data-file", "n");
      if (globalData == "Y") {
        let getData = $(a)
          .parent()
          .parent();
        $(getData).attr("data-mandatory", "Y");
      } else {
        let getData = $(a)
          .parent()
          .parent();
        $(getData).attr("data-mandatory", "N");
      }
      $(a).remove();
      if ($(".fileName").length > 0) {
        $("#uploadToPortal, #saveAsDraft, #discard").attr(
          "disabled",
          false
        );
      } else {

        $("#uploadToPortal, #saveAsDraft, #discard").attr(
          "disabled",
          true
        );
      }
    },
    complete: function () {
      $(".spinner-container").hide();
    },

    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/CandidateLogin.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
}

function downloadFile(id) {
  var label = $(id)
    .next()
    .find("span")
    .text();

  $.ajax({
    type: "POST",
    url: candBaseUrl + "api/DocUpload/DownloadFile",
    //dataType:"json",
    async: true,
    processData: false,
    beforeSend: function () {
      $(".spinner-container").show();
    },
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    data: JSON.stringify({
      UserID: $("#loginDetails").text(),
      Roles: "Candidate",
      CanEmailID: $("#loginDetails").text(),
      FileName: label
    }),
    success: function (response, status, xhr) {
      $("#Dklm").val(response.Dklm);
      $("#Dilm").val(response.Dilm);
      var key = CryptoJS.enc.Utf8.parse($("#Dklm").val());
      var iv = CryptoJS.enc.Utf8.parse($("#Dilm").val());
      function decrypt(crypt, key) {
        var decrypted = CryptoJS.AES.decrypt(crypt, key, {
          iv: iv,
          padding: CryptoJS.pad.Pkcs7,
          mode: CryptoJS.mode.CBC
        });
        return decrypted;
      }
      var dec = decrypt(response.TextValue, key);
      var base64str = dec.toString(CryptoJS.enc.Utf8);

      var binary = atob(base64str.replace(/\s/g, ""));
      var len = binary.length;
      var buffer = new ArrayBuffer(len);
      var view = new Uint8Array(buffer);
      for (var i = 0; i < len; i++) {
        view[i] = binary.charCodeAt(i);
      }

      var userAgent = navigator.userAgent || navigator.vendor || window.opera;
      var blob = new Blob([view], { type: "application/pdf" });
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        let staffId = $("#candidateStaffId").val();
        var label1 = label.split('_');
        var file = '';
        if (staffId == "") {
          file = label1[1] + "_" + label1[2];
        } else {
          file = staffId + "_" + label1[1] + "_" + label1[2];
        }
        window.navigator.msSaveOrOpenBlob(blob, file);
      } else if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)) { //Safari & Opera iOS

        let url = window.URL.createObjectURL(blob);
        window.location.href = url;
      } else {
        var a = document.createElement("a");
        var url = window.URL.createObjectURL(blob);
        a.href = url;
        let staffId = $("#candidateStaffId").val();
        let label1 = label.split('_');
        if (staffId == "") {
          a.download = label1[1] + "_" + label1[2];
          a.click();
        } else {
          a.download = staffId + "_" + label1[1] + "_" + label1[2];
          a.click();
        }

        window.URL.revokeObjectURL(url);
      }
    },
    complete: function () {
      $(".spinner-container").hide();
    },

    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/CandidateLogin.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
}

function downloadStandardForm(id) {
  let fileName = id.innerHTML;
  let newFile = fileName + ".pdf";
  if (fileName == "N/A") {
    alert("No file available for download");
  } else {
    $.ajax({
      type: "POST",
      url: candBaseUrl + "api/DocUpload/StandardFormsDownload",
      //dataType:"json",
      async: true,
      processData: false,
      contentType: "application/json",
      beforeSend: function () {
        $(".spinner-container").show();
      },
      crossDomain: true,
      xhrFields: {
        responseType: "blob", withCredentials: true
      },
      data: JSON.stringify({
        UserID: $("#loginDetails").text(),
        Roles: "Candidate",
        FileName: newFile
      }),
      success: function (response) {
        var a = document.createElement("a");
        // var url = window.URL.createObjectURL(response);  
        var userAgent = navigator.userAgent || navigator.vendor || window.opera;
        var blob = new Blob([response], { type: "application/pdf" });
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, newFile);
        } else if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i)) { //Safari & Opera iOS
          let url = window.URL.createObjectURL(blob);
          window.location.href = url;
        } else {
          var url = window.URL.createObjectURL(response);
          a.href = url;
          a.download = newFile;
          a.click();
          window.URL.revokeObjectURL(url);
          a.remove();
        }
      },
      complete: function () {
        $(".spinner-container").hide();
      },


      error: function (jqXHR, error, errorThrown) {
        if (jqXHR.status == 401) {
          $.alert({
            icon: "fas fa-exclamation-circle fa-5x",
            title: "",
            theme: "my-theme",
            content: "Session Timed Out",
            buttons: {
              ok: function () {

                window.location.assign(accessUrl + "/CandidateLogin.html");
              }
            }
          });
        } else if (jqXHR.status && jqXHR.status == 400) {
          window.location.assign(accessUrl + "/502.html");
        } else {
          window.location.assign(accessUrl + "/502.html");
        }
      }
    });
  }
}


function common() {
  if ($("#appendedListCandid li").length == 0) {
    $.alert({
      icon: "fas fa-exclamation-circle fa-5x",
      title: "",
      theme: "my-theme",
      content: "Please attach at least one file"
    });
    return;
  }
  let items = $("#appendedListCandid li span.styleList")
    .map(function () {
      return $(this).text();
    })
    .get()
    .join("'.',");
  var heading = $("#labelheadUpload").text();
  let spl = heading.replace(/ *\([^)]*\) */g, "");
  let star = spl.replace(/\*/g, "");
  let slash = star.replace(/\//g, "");
  let colon = slash.replace(/\:/g, "");
  let dot = colon.replace(/\./g, "");
  var reg = new RegExp(/(\r\n?|\n|\t)/g);
  var ntext = dot.replace(reg, " ");
  var MText = ntext.replace(/\#/g, "");
  var CText = MText.replace(/\s+$/, '');
  var array = items.split("'.',");
  var names = {
    UserID: $("#loginDetails").text(),
    Roles: "Candidate",
    Dklm: $("#Dklm").val(),
    Dilm: $("#Dilm").val(),
    CanEmailID: $("#loginDetails").text(),
    Values: []
  };
  for (var i = 0; i < array.length; i++) {
    names.Values.push({ FileLabel: CText, FileName: array[i] });
  }

  $.ajax({
    type: "POST",
    url: candBaseUrl + "/api/DocUpload/Create_pdf",
    async: true,
    processData: false,
    beforeSend: function () {
      $(".spinner-container").show();
    },
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    data: JSON.stringify(names),
    success: function (response) {
      var res = JSON.parse(response);
      if (res.Status == "Success") {
        $("#uploadModalCandid").modal("hide");
        var key = CryptoJS.enc.Utf8.parse($("#Dklm").val());
        var iv = CryptoJS.enc.Utf8.parse($("#Dilm").val());
        function decrypt(crypt, key) {
          var decrypted = CryptoJS.AES.decrypt(crypt, key, {
            iv: iv,
            padding: CryptoJS.pad.Pkcs7,
            mode: CryptoJS.mode.CBC
          });
          return decrypted;
        }
        var dec = decrypt(res.Message, key);
        var base64str = dec.toString(CryptoJS.enc.Utf8);

        var binary = atob(base64str.replace(/\s/g, ""));
        var len = binary.length;
        var buffer = new ArrayBuffer(len);
        var view = new Uint8Array(buffer);
        for (var i = 0; i < len; i++) {
          view[i] = binary.charCodeAt(i);
        }

        var blob = new Blob([view], { type: "application/pdf" });
        let parentElement = $("#accordionExample table td span").filter(
          function () {
            return $(this).text() == heading;
          }
        );
        var ab = $(parentElement)
          .parent()
          .parent();
        var x = $(ab).attr("data-mandatory");
        globalData = x;

        var a = document.createElement("a");
        var b = document.createElement("a");
        var c =
          " <b class='ml-2' style='cursor:pointer' onclick='deleteMerged(this)'> X </b>";

        var url = window.URL.createObjectURL(blob);
        a.href = "#";
        b.href = url;
        b.download = CText;
        a.innerHTML = $("#candidUploadNum").val() + "_" + CText;
        a.setAttribute("onclick", "previewTempFile(this)");
        a.setAttribute("class", "fileName");
        var icon =
          '<i class="fas fa-download ml-2 mr-2 fa-lg"  data-toggle="tooltip" data-placement="top" title="Download File"></i>';
        b.innerHTML = icon;
        var pdfIcon = '<i class="far fa-file-pdf fa-lg text-danger mr-2"></i>';
        let fileAttached = '<div class="FAttached"><br>File Attached</div>';
        $(parentElement)
          .parent()
          .append("<div class='fileMerged'>");
        $(parentElement)
          .parent()
          .find(".fileMerged")
          .append("<br>");
        $(parentElement)
          .parent()
          .find(".fileMerged")
          .append(b);
        $(parentElement)
          .parent()
          .find(".fileMerged")
          .append(pdfIcon);
        $(parentElement)
          .parent()
          .find(".fileMerged")
          .append(a);
        $(parentElement)
          .parent()
          .find(".fileMerged")
          .append(c);
        $(parentElement)
          .parent()
          .next()
          .find(".FNSelected")
          .hide();
        $(parentElement)
          .parent()
          .next().text("");
        $(parentElement)
          .parent()
          .next()
          .append(fileAttached);
        $(parentElement)
          .parent()
          .find(".NACheck")
          .parent()
          .hide();
        if (x == "Y") {
          var getData = $(parentElement)
            .parent()
            .parent();
          $(getData).attr("data-mandatory", "N");
        }
        $(parentElement).parent().parent().attr("data-file", "y");
        $("inputFileUpload").val("");
        fileCount = 0;
        fileArray = [];
        $("#uploadToPortal, #saveAsDraft, #discard").attr("disabled", false);
      } else {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: res.Message
        });
      }
    },
    complete: function () {
      $(".spinner-container").hide();
    },


    error: function (jqXHR, error, errorThrown) {
      if (jqXHR.status == 401) {
        $.alert({
          icon: "fas fa-exclamation-circle fa-5x",
          title: "",
          theme: "my-theme",
          content: "Session Timed Out",
          buttons: {
            ok: function () {

              window.location.assign(accessUrl + "/CandidateLogin.html");
            }
          }
        });
      } else if (jqXHR.status && jqXHR.status == 400) {
        window.location.assign(accessUrl + "/502.html");
      } else {
        window.location.assign(accessUrl + "/502.html");
      }
    }
  });
}
