$(document).ready(function () {
    let loginDetails;
    $.ajax({
        type: "GET",
        url: baseUrl + "api/User/LoggedUserDetails",
        dataType: "json",
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        success: function (response) {
            var res = JSON.parse(response);
            loginDetails = res.output_data[0]['UserID'];


        },
        complete: function () {

            $.ajax({
                type: "POST",
                url: baseUrl + "api/User/DeactivateToken",
                contentType: "application/json",
                crossDomain: true,
                xhrFields: { withCredentials: true },
                beforeSend: function () {
                    $(".spinner-container").show();
                },
                data: JSON.stringify({
                    UserName: loginDetails,
                }),
                success: function (response) {
                    $(".spinner-container").hide();

                }
            });
        }
    });

});