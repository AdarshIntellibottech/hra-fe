function checkSession() {
    $.ajax({
        type: "GET",
        url: baseUrl + "api/User/LoggedUserDetails",
        dataType: "json",
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        success: function (response) {
            var res = JSON.parse(response);
            var userName = res.output_data[0]['UserID'];
            var roleType = res.output_data[0]['Role'];
            $.ajax({
                type: "POST",
                url: baseUrl + "api/User/IsTokenValid",
                dataType: "json",
                contentType: "application/json",
                crossDomain: true,
                xhrFields: { withCredentials: true },
                data: JSON.stringify({
                    UserName: userName,
                    Roles: roleType
                }),
                success: function (response) {
                    var res = JSON.parse(response);

                    if (res == false) {
                        $.alert({
                            icon: "fas fa-exclamation-circle fa-5x",
                            title: "",
                            theme: "my-theme",
                            content: "Session Timed Out",
                            buttons: {
                                ok: function () {

                                    window.location.assign(accessUrl + "/Login.html");
                                }
                            }
                        });
                    } else {
                        return;
                    }
                },

                error: function (jqXHR, error, errorThrown) {
                    if (jqXHR.status && jqXHR.status == 400) {
                        window.location.assign(accessUrl + "/502.html");
                    } else {
                        window.location.assign(accessUrl + "/502.html");
                    }
                }
            });
        },
        error: function (jqXHR, error, errorThrown) {
            if (jqXHR.status && jqXHR.status == 400) {
                window.location.assign(accessUrl + "/Login.html");
            } else {
                window.location.assign(accessUrl + "/Login.html");
            }
        }
    });
}
$(document).ready(function () {
    setInterval(checkSession, 1200000);

    $("#loginDetails").text($("#loginDetails").text());

    $("#logOut").on("click", function () {
        window.location.href = accessUrl + "/Logout.html";
    });
});