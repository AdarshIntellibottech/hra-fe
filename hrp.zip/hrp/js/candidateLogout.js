$(document).ready(function () {
    let userId;
    $.ajax({
        type: "POST",
        url: candBaseUrl + "api/Candidate/CandidateInfo",
        //dataType: "json",
        contentType: "application/json",
        beforeSend: function () {
            $(".spinner-container").show();
        },
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({
            Roles: "Candidate",
        }),
        success: function (response) {
            userId = response.CandidateEmailID;
        },
        complete: function () {
            $.ajax({
                type: "POST",
                url: candBaseUrl + "api/Candidate/CanPrivacy",
                //dataType: "json",
                contentType: "application/json",
                beforeSend: function () {
                    $(".spinner-container").show();
                },
                crossDomain: true,
                xhrFields: { withCredentials: true },
                data: JSON.stringify({
                    UserID: userId,
                    Roles: "Candidate",
                    PrivacyFlag: "Null",
                    CanEmailID: userId

                }),
                success: function (response) {
                    let res = JSON.parse(response);
                    console.log("check response ======= " + response);

                },
                complete: function () {
                    $.ajax({
                        type: "POST",
                        url: baseUrl + "api/User/DeactivateToken",
                        contentType: "application/json",
                        crossDomain: true,
                        xhrFields: { withCredentials: true },
                        beforeSend: function () {
                            $(".spinner-container").show();
                        },
                        data: JSON.stringify({
                            UserName: userId
                        }),
                        success: function (response) {
                            $(".spinner-container").hide();

                        }
                    });

                }
            });
        }
    });
});