$(document).ready(function () {

  $.ajax({
    type: "GET",
    url: baseUrl + "api/User/LoggedUserDetails",
    dataType: "json",
    contentType: "application/json",
    crossDomain: true,
    xhrFields: { withCredentials: true },
    success: function (response) {
      let res = JSON.parse(response);
      $("#roleType").val(res.output_data[0]['Role']);
      $("#loginDetails").text(res.output_data[0]['UserID']);
    },

    complete: function () {

      var baseurl = window.location.search;
      var userId = baseurl.split('=').pop();

      var userUrl = baseUrl + "api/User/GetUser";
      $.ajax({
        type: "POST",
        url: userUrl,
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({
          UserID: $("#loginDetails").text(),
          Roles: $("#roleType").val(),
          EditUserID: userId
        }),
        success: function (response) {
          var res = response['0'];
          $("#FirstName").val(res.FirstName);
          $("#LastName").val(res.LastName);
          $("#EmailID").val(res.EmailID);
          $("#UserName").val(res.UserName);
          $("#StrPassword").val(res.UserName);
          if (res.UserRole == 'Admin') {
            $("#roleid option[value=1]").prop("selected", "selected")
          }
          else if (res.UserRole == 'HROps') {
            $("#roleid option[value=2]").prop("selected", "selected")
          } else if (res.UserRole == 'Recruiter') {
            $("#roleid option[value=3]").prop("selected", "selected")
          } else {
            $("#roleid option[value=0]").prop("selected", "selected")
          }

        },

        error: function (jqXHR, error, errorThrown) {
          if (jqXHR.status == 401) {
            $.alert({
              icon: "fas fa-exclamation-circle fa-5x",
              title: "",
              theme: "my-theme",
              content: "Session Timed Out",
              buttons: {
                ok: function () {

                  window.location.assign(accessUrl + "/Login.html");
                }
              }
            });
          } else if (jqXHR.status && jqXHR.status == 400) {
            window.location.assign(accessUrl + "/502.html");
          } else {
            window.location.assign(accessUrl + "/502.html");
          }
        }
      });

      let url = baseUrl + "api/User/AddEditUser";
      $("#editUserSubmit").validate({
        rules: {
          FirstName: {
            required: true
          },
          LastName: {
            required: true
          },
          EmailID: {
            required: true
          },
          UserName: {
            required: true,
          },
          roleid: {
            required: true
          },
        },
        messages: {
          FirstName: {
            required: "First Name is required"
          },
          LastName: {
            required: "Last Name is required"
          },
          EmailID: {
            required: "Email Id is required"
          },
          UserName: {
            required: "Username is required"
          },
          roleid: {
            required: "Please select a role"
          }
        },
        errorElement: "em",
        errorPlacement: function (error, element) {
          error.addClass("help-block");
          if (element.prop("type") === "checkbox") {
            error.insertAfter(element.parent("label"));
          } else {
            error.insertAfter(element);
          }
        },
        onfocusout: function (element) {
          this.element(element);
        },
        highlight: function (element, errorClass, validClass) {
          $(element)
            .parents(".form-group")
            .addClass("has-error")
            .removeClass("has-success");
        },
        unhighlight: function (element, errorClass, validClass) {
          $(element)
            .parents(".form-group")
            .addClass("has-success")
            .removeClass("has-error");
          return false;
        },
        submitHandler: function (form) {
          let data = {
            UserID: $("#loginDetails").text(),
            Roles: $("#roleType").val(),
            FirstName: $("#FirstName").val(),
            LastName: $("#LastName").val(),
            UserName: $("#UserName").val(),
            StrPassword: $("#UserName").val(),
            EmailID: $("#EmailID").val(),
            roleid: $("#roleid").val(),
            EditUserID: userId
          };
          $.ajax({
            type: "POST",
            url: url,
            dataType: "json",
            contentType: "application/json",
            crossDomain: true,
            xhrFields: { withCredentials: true },
            data: JSON.stringify(data),
            beforeSend: function () {
              $(".spinner-container").removeClass("d-none");
            },
            success: function (response) {
              var res = JSON.parse(response);
              $(".spinner-container").addClass("d-none");
              if (res.Status == "Success") {
                $.alert({
                  icon: "far fa-check-circle fa-5x",
                  title: "",
                  theme: "green-theme",
                  content: res.Message,
                  buttons: {
                    ok: function () {
                      window.location.assign(accessUrl + "/UserList.html");
                    }
                  }
                });
              } else {
                $.alert({
                  icon: "fas fa-exclamation-circle fa-5x",
                  title: "",
                  theme: "my-theme",
                  content: res.Message
                });
              }
            },

            error: function (jqXHR, error, errorThrown) {
              if (jqXHR.status == 401) {
                $.alert({
                  icon: "fas fa-exclamation-circle fa-5x",
                  title: "",
                  theme: "my-theme",
                  content: "Session Timed Out",
                  buttons: {
                    ok: function () {

                      window.location.assign(accessUrl + "/Login.html");
                    }
                  }
                });
              } else if (jqXHR.status && jqXHR.status == 400) {
                window.location.assign(accessUrl + "/502.html");
              } else {
                window.location.assign(accessUrl + "/502.html");
              }
            }
          });
        }
      });
    }
  });


});
