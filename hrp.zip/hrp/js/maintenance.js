$(document).ready(function () {

    /* This is the Login page maintenance flash msg settings - Update one week before the scheduled maintenance */
    const isMaintenanceFlashMsgActive = false; // to display msg make this value true else false
    const message = "E-Offer Portal will not be accessible from 00:00 18th June to \
    23:59 19th June due to scheduled maintenance activity.";
    /* This is the Login page maintenance flash msg settings - Update one week before the scheduled maintenance */

    /* This is the maintenance modal box in internal page settings - Update 30 minutes before the scheduled maintenance */
    const isInternalModalBoxActive = false; // to display msg make this value true else false
    const internalModalBoxMsg = "E-Offer Portal will not be accessible from 00:00 18th June to \
    23:59 19th June due to scheduled maintenance activity. Please save your work to prevent \
    loss of data."
    /* This is the maintenance modal box in internal page settings - Update 30 minutes before the scheduled maintenance */

    if (isMaintenanceFlashMsgActive) {
        $(".modal-text").text(message);
        $("#sysMaintenance").show();
    } else {
        $("#sysMaintenance").hide();
    }

    if (isInternalModalBoxActive) {
        $(".internal-text").text(internalModalBoxMsg);
        $("#systemMaintenance").modal('show');
    } else {
        $("#systemMaintenance").modal('hide');
    }
});