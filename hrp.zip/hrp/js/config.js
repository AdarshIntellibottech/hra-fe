window.baseUrl =
  "https://cefah002.prcloudmgmt.intraxa/HRA_Internal/";
  
window.candBaseUrl =
  "https://cefah002.prcloudmgmt.intraxa/HRA_External/";

window.accessUrl = "https://cefah002.prcloudmgmt.intraxa/hrp";

$.fn.serializeObject = function () {
  var o = {};
  var a = this.serializeArray();
  $.each(a, function () {
    if (o[this.name] !== undefined) {
      if (!o[this.name].push) {
        o[this.name] = [o[this.name]];
      }
      o[this.name].push(this.value || "");
    } else {
      o[this.name] = this.value || "";
    }
  });
  return o;
};

$(document).ready(function () {
  $('[data-toggle="tooltip"]').tooltip();
  jQuery.validator.addMethod(
    "noSpace",
    function (value, element) {
      return value == "" || value.trim().length != 0;
    },
    "No space please and don't leave it empty"
  );

  jQuery.validator.addMethod(
    "lettersonly",
    function (value, element) {
      return this.optional(element) || /^[a-z ',-.`:;"_]+$/i.test(value);
    },
    "Letters spaces only please"
  );
  $.validator.addMethod("filesize", function (value, element, arg) {
    var minsize = 1000; // min 1kb
    if (value > minsize && value <= arg) {
      return true;
    } else {
      return false;
    }
  });
});
