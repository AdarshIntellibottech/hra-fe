function getDetails() {

    $.ajax({
        type: "POST",
        url: baseUrl + "api/Candidate/GetCookieDetails",
        //dataType: "json",
        contentType: "application/json",
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({
            CandidateID: $("#CandidateId").val(),
            JobID: $("#JobId").val(),
            JobTitle: $("#JobTitle").val(),
            Roles: "Candidate",
            UserID: $("#loginDetails").text()
        }),
        success: function (response) {
            console.log();
        },
        complete: function () {
            $.ajax({
                type: "GET",
                url: baseUrl + "api/Candidate/GetPrivacy",
                dataType: "json",
                contentType: "application/json",
                crossDomain: true,
                xhrFields: { withCredentials: true },
                success: function (response) {
                    let res = JSON.parse(response);
                    if (res.Message == "Accepted") {
                        window.location.href = accessUrl + "/CandidateDocumentUpload.html";
                    }
                    
                    else {
                        return false;
                    }
                    console.log(response);
                }
            });
        }
    });

}
$(document).ready(function () {
    $.ajax({
        type: "POST",
        url: candBaseUrl + "api/Candidate/CandidateInfo",
        //dataType: "json",
        contentType: "application/json",
        beforeSend: function () {
            $(".spinner-container").show();
        },
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({
            Roles: "Candidate"

        }),
        success: function (response) {
            $("#loginName").text(response.CandidateFirstName + ' ' + response.CandidateLastName);
            $('#loginDetails').text(response.CandidateEmailID);
            $("#JobTitle").val(response.JobTitle);
            $("#JobId").val(response.JobID);
            $("#CandidateId").val(response.CandidateID);
            $(".spinner-container").hide();
        },
        complete: function () {
            getDetails();
        },

        error: function (jqXHR, error, errorThrown) {
            if (jqXHR.status && jqXHR.status == 400) {
                window.location.assign(accessUrl + "/502.html");
            } else {
                window.location.assign(accessUrl + "/502.html");
            }
        }
    });


    $(".languageSelect").change(function () {
        var selectedLanguage = $(this).children("option:selected").val();
        if (selectedLanguage === "fr-FR") {
            $("#privacyIframe3").removeClass('d-none');
            $("#privacyIframe2").addClass('d-none');
            $("#privacyIframe1").addClass('d-none');
        } else if (selectedLanguage === "de") {
            $("#privacyIframe2").removeClass('d-none');
            $("#privacyIframe3").addClass('d-none');
            $("#privacyIframe1").addClass('d-none');
        } else {
            $("#privacyIframe1").removeClass('d-none');
            $("#privacyIframe3").addClass('d-none');
            $("#privacyIframe2").addClass('d-none');
        }
    });




    $("#privacyAcc").on("click", function () {
        let checked = $(this).attr("data-check");
        getPolicyCheck(checked, "/CandidateDocumentUpload.html");
        // window.location.href = accessUrl + "/CandidateDocumentUpload.html";
    });

    $("#privacyDec").on("click", function () {
        let checked = $(this).attr("data-check");
        getPolicyCheck(checked, "/privacyDec.html");
        //window.location.href = accessUrl + "/privacyDec.html";
    })
})

//common function for Policy value
function getPolicyCheck(check, loc) {
    $.ajax({
        type: "POST",
        url: candBaseUrl + "api/Candidate/CanPrivacy",
        //dataType: "json",
        contentType: "application/json",
        beforeSend: function () {
            $(".spinner-container").show();
        },
        crossDomain: true,
        xhrFields: { withCredentials: true },
        data: JSON.stringify({
            UserID: $("#loginDetails").text(),
            Roles: "Candidate",
            PrivacyFlag: check,
            CanEmailID: $("#loginDetails").text()

        }),
        success: function (response) {
            let res = JSON.parse(response);
            window.location.href = accessUrl + loc;
            $(".spinner-container").hide();
        }
    });

}